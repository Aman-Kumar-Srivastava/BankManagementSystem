package Bank.Management.System;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.awt.print.*;

public class MiniStatement extends JFrame implements ActionListener{
 
    JButton b1, b2,submit,print;
    JLabel l0,l1,l2,l3,l4;
    JTextField t0;
    MiniStatement(String pin){
        //super("Mini Statement");
    	super();
        getContentPane().setBackground(Color.WHITE);
        setSize(400,600);
        setLocation(20,20);
        
        l1 = new JLabel();
        add(l1);
        
        l2 = new JLabel("My Bank");
        l2.setBounds(150, 20, 100, 20);
        add(l2);
        
        l0 = new JLabel("Enter Your Account No: ");
        l0.setBounds(50, 50, 150, 40);
        add(l0);
        
        
        t0 = new JTextField();
        t0.setFont(new Font("Raleway", Font.BOLD, 14));
        t0.setBounds(200, 55, 180, 30);
        add(t0);
        
        l3 = new JLabel();
        l3.setBounds(20, 120, 300, 20);
        add(l3);
        
        l4 = new JLabel();
        l4.setBounds(20, 400, 300, 20);
        add(l4);
        
        submit = new JButton("Submit");
        submit.setBounds(200, 85, 80, 30);
        submit.setFont(new Font("Raleway", Font.BOLD, 12));
        submit.addActionListener(this);
        add(submit);
        
        print = new JButton("Print");
        print.setBounds(300, 85, 80, 30);
        print.setFont(new Font("Raleway", Font.BOLD, 12));
        print.addActionListener(this);
        add(print);
        
        setLayout(null);
        b1 = new JButton("Exit");
        add(b1);
        
        b1.addActionListener(this);
        
        l1.setBounds(20, 140, 400, 200);
        b1.setBounds(20, 500, 100, 25);
    }
    public void actionPerformed(ActionEvent ae){
    	if(ae.getSource()==submit) {
    		
    		String customerId=t0.getText();
try{
	        
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from login1 where customerId = '"+customerId+"'");
            while(rs.next()){
                l3.setText("Customer Id:    " + rs.getString("customerId").substring(0, 4) + "XXXXXXXX" + rs.getString("customerId").substring(12));
            }
        }catch(Exception e){}
        	 
        try{
        	
            int balance = 0;
            Conn c1  = new Conn();
            ResultSet rs = c1.s.executeQuery("SELECT * FROM bank3 where customerId = '"+customerId+"'");
            while(rs.next()){
                l1.setText(l1.getText() + "<html>"+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("type") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("amount") + "<br><br><html>");
                if(rs.getString("type").equals("Deposit")){
                    balance += Integer.parseInt(rs.getString("amount"));
                }else{
                    balance -= Integer.parseInt(rs.getString("amount"));
                }
            }
            l4.setText("Your total Balance is Rs "+balance);
        }catch(Exception e){
            e.printStackTrace();
        }
        //this.setVisible(false);
        //new Transactions("").setVisible(true);
    }
    	if(ae.getSource()==b1) {
    		setVisible(false);
    		new Transactions("").setVisible(true);
    	}
    if (ae.getSource() == print) {
    	PrinterJob statements = PrinterJob.getPrinterJob();
    	statements.setJobName("Print");



    	statements.setPrintable(new Printable(){
    	public int print(Graphics gp, PageFormat pf, int pageNum){
    	if(pageNum>0){
    	return Printable.NO_SUCH_PAGE;
    	}
    	Graphics2D g2d = (Graphics2D)gp;
    	g2d.translate(pf.getImageableX(),pf.getImageableY());
    	paint(g2d);
    	return Printable.PAGE_EXISTS;



    	}
    	});
    	boolean ok = statements.printDialog();
    	if(ok){
    	try{
    	statements.print();
    	setVisible(false);
    	} catch(Exception e){



    	}
    	}
    	}
    }
    
    public static void main(String[] args){
    
        new MiniStatement("").setVisible(true);
    }
    
}