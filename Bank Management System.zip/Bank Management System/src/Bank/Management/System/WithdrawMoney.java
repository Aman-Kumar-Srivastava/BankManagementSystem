package Bank.Management.System;
import java.awt.Color;

import javax.swing.*;
public abstract class WithdrawMoney extends OutputScreenGUI {
	 
		 public String currentBalance(String s){		    	
		  	 String amount = "";
		  	 String balance="";
		  	 int c=0;
			  c =Integer.parseInt(s)-Integer.parseInt(amount);
		      System.out.println(c);
		      balance=""+Integer.toString(c);
		      return balance;		      
		   }
	}