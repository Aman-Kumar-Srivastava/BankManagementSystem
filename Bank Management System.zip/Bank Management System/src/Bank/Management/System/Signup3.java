package Bank.Management.System;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

public class Signup3 extends OutputScreenGUI implements ActionListener{
    
    JLabel l1,l2,l22,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
    JTextField t22;
    JRadioButton r1,r2,r3,r4;
    JButton b1,b2;
    JCheckBox c1,c2,c3,c4,c5,c6,c7;
    JComboBox c0;
    String name;
    String formno;
    String pin;
    String password;
//    String ChequebookNo;
//    String CardNo;
    String customerId;
    Signup3(String formno, String name){
    	this.name=name;
        this.formno = formno;
        setTitle("ISSUE OF CARD/CHEQUE-BOOK");
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/skyblue.jfif"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l0 = new JLabel(i3);
        l0.setBounds(0, 0, 960, 1080);
        add(l0);
        l1 = new JLabel("ACCOUNT DETAILS");
        l1.setFont(new Font("Raleway", Font.BOLD, 22));
        
        l2 = new JLabel("Account Type:");
        l2.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l22= new JLabel("Customer Id:");
        l22.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l3 = new JLabel("Card Number:");
        l3.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l4 = new JLabel("5040-9367-XXXX-XXXX");
        l4.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l5 = new JLabel("(Your 16-digit Card No)");
        l5.setFont(new Font("Raleway", Font.BOLD, 12));
        
        l6 = new JLabel("It would appear on Pass Book / Cheque Book and Statements");
        l6.setFont(new Font("Raleway", Font.BOLD, 12));
        
        l7 = new JLabel("PIN:");
        l7.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l8 = new JLabel("XXXX");
        l8.setFont(new Font("Raleway", Font.BOLD, 18));
    
        l9 = new JLabel("(4-digit pin)");
        l9.setFont(new Font("Raleway", Font.BOLD, 12));
    
        l10 = new JLabel("Services Required:");
        l10.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l11 = new JLabel("Form No:");
        l11.setFont(new Font("Raleway", Font.BOLD, 14));
        
        l12 = new JLabel(formno);
        l12.setFont(new Font("Raleway", Font.BOLD, 14));
        
        b1 = new JButton("Submit");
        b1.setFont(new Font("Raleway", Font.BOLD, 14));
        b1.setBackground(Color.BLUE);
        b1.setForeground(Color.WHITE);
        
        b2 = new JButton("Cancel");
        b2.setFont(new Font("Raleway", Font.BOLD, 14));
        b2.setBackground(Color.BLUE);
        b2.setForeground(Color.WHITE);
        
        
        c1 = new JCheckBox("DEBIT CARD");
        c1.setBackground(Color.WHITE);
        c1.setFont(new Font("Raleway", Font.BOLD, 16));
        
        c2 = new JCheckBox("CREDIT CARD");
        c2.setBackground(Color.WHITE);
        c2.setFont(new Font("Raleway", Font.BOLD, 16));
        
        c3 = new JCheckBox("Mobile Banking");
        c3.setBackground(Color.WHITE);
        c3.setFont(new Font("Raleway", Font.BOLD, 16));
        
        c4 = new JCheckBox("EMAIL Alerts");
        c4.setBackground(Color.WHITE);
        c4.setFont(new Font("Raleway", Font.BOLD, 16));
        
        c5 = new JCheckBox("Cheque Book");
        c5.setBackground(Color.WHITE);
        c5.setFont(new Font("Raleway", Font.BOLD, 16));
        
        c6 = new JCheckBox("E-Statement");
        c6.setBackground(Color.WHITE);
        c6.setFont(new Font("Raleway", Font.BOLD, 16));
        
        c7 = new JCheckBox("I hereby declares that the above entered details correct to the best of my knowledge.",true);
        c7.setBackground(Color.WHITE);
        c7.setFont(new Font("Raleway", Font.BOLD, 12));
         
        t22 = new JTextField();
        t22.setFont(new Font("Raleway", Font.BOLD, 14));
        

        String accountType[] = {"","Saving Account","Current Account","Fixed Deposit Account","Recurring Deposit Account"};
        c0 = new JComboBox(accountType);
        c0.setBackground(Color.WHITE);
        c0.setFont(new Font("Raleway", Font.BOLD, 14));
        
        ButtonGroup groupgender = new ButtonGroup();
        groupgender.add(r1);
        groupgender.add(r2);
        groupgender.add(r3);
        groupgender.add(r4);
        
        setLayout(null);
        
        l11.setBounds(700,10,70,30);
        l0.add(l11);
        
        l12.setBounds(770,10,40,30);
        l0.add(l12);
        
        l1.setBounds(280,40,400,40);
        l0.add(l1); 
        
        l2.setBounds(100,100,200,30);
        l0.add(l2);
        
        c0.setBounds(300,100,200,30);
        l0.add(c0);
        
        l22.setBounds(100,200,200,30);
        l0.add(l22);
        
        t22.setBounds(300,200,250,30);
        l0.add(t22);
        
        
        l3.setBounds(100,240,200,30);
        l0.add(l3);
        
        l4.setBounds(330,240,250,30);
        l0.add(l4);
        
        l5.setBounds(100,270,200,20);
        l0.add(l5);
        
        l6.setBounds(330,270,500,20);
        l0.add(l6);
        
        l7.setBounds(100,310,200,30);
        l0.add(l7);
        
        l8.setBounds(330,310,200,30);
        l0.add(l8);
        
        l9.setBounds(100,340,200,20);
        l0.add(l9);
        
        l10.setBounds(100,390,200,30);
        l0.add(l10);
        
        c1.setBounds(100,420,200,30);
        l0.add(c1);
        
        c2.setBounds(350,420,200,30);
        l0.add(c2);
        
        c3.setBounds(100,460,200,30);
        l0.add(c3);
        
        c4.setBounds(350,460,200,30);
        l0.add(c4);
        
        c5.setBounds(100,500,200,30);
        l0.add(c5);
        
        c6.setBounds(350,500,200,30);
        l0.add(c6);
        
        c7.setBounds(100,550,600,20);
        l0.add(c7);
        
        b1.setBounds(420,590,100,30);
        l0.add(b1);
        
        b2.setBounds(550,590,100,30);
        l0.add(b2);
        
        
        getContentPane().setBackground(Color.WHITE);
        
        setSize(850,850);
        setLocation(0,0);
        setVisible(true);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        
    }
    
    public void actionPerformed(ActionEvent ae){

        String atype = (String)c0.getSelectedItem(); 
        String custId = t22.getText();
        Random ran = new Random();


        String CreditCardNo=null;
        String DebitCardNo=null;
        String pin1=null;
        String pin2=null;
        String ChequeBookNo=null;

        String facility = "";
        if(c1.isSelected()){ 
            facility = facility + " Debit-Card";
            long first8 = (ran.nextLong() % 9000000L) + 5040936700000000L;
            DebitCardNo = "" + Math.abs(first8);
            long first4 = (ran.nextLong() % 9000L) + 1000L;
            pin1 = "" + Math.abs(first4);	 
        }
        if(c2.isSelected()){ 
            facility = facility + " Credit-Card";
            long first10 = (ran.nextLong() % 9000000L) + 5040936700000000L;
            CreditCardNo = "" + Math.abs(first10);
            long first5 = (ran.nextLong() % 9000L) + 1000L;
            pin2 = "" + Math.abs(first5);	 
        }
        if(c3.isSelected()){ 
            facility = facility + " Mobile Banking";
        }
        if(c4.isSelected()){ 
            facility = facility + " EMAIL Alerts";
        }
        if(c5.isSelected()){ 
            facility = facility + " Cheque-Book";
            long first9 = (ran.nextLong() % 90000000L) + 9360000000L;
            ChequeBookNo = "" + Math.abs(first9);
        }
        if(c6.isSelected()){ 
            facility = facility + " E-Statement";
        }
        System.out.println(facility);
        
        try{
            if(ae.getSource()==b1){
            	if(custId.equals("")){
                    JOptionPane.showMessageDialog(null, "please enter customer Id");
            }
                
            	else if(atype.equals("")){
                        JOptionPane.showMessageDialog(null, "please select account type");
                }

            	else if(facility.equals("")){
                     JOptionPane.showMessageDialog(null, "please select any facility");
                 }

                 else if(!c1.isSelected() && !c5.isSelected() && !c2.isSelected()) {
                	 JOptionPane.showMessageDialog(null,"Please select one facility atleast \n Cheque-Book or Card"); 
                 }
                 else{
                	 
                    Conn d1 = new Conn();
                    String query = "select * from login1 where customerId = '"+custId+"'";
                    ResultSet rs = d1.s.executeQuery(query);
                    if(!rs.next()) {
                    	JOptionPane.showMessageDialog(null, "Incorrect Customer Id");
                    }
                    else {	
                    String q1 = "insert into signup33 values('"+formno+"','"+custId+"','"+atype+"','"+ChequeBookNo+"','"+DebitCardNo+"','"+pin1+"','"+CreditCardNo+"','"+pin2+"','"+facility+"')";  

                    d1.s.executeUpdate(q1);
                   
                    JOptionPane.showMessageDialog(null,"\n DebitCardNo: "+DebitCardNo+"\n Pin: "+pin1+"\n CreditCardNo:"+CreditCardNo+ "\n Pin: " +pin2+ "\n ChequeBookNo: "+ChequeBookNo );
                    
                   
//                    new Deposit(password).setVisible(false);
//                    setVisible(false);
                    new ChequebookAndCard(pin, ChequeBookNo, DebitCardNo, CreditCardNo, name).setVisible(true);
                    setVisible(false);
                    setVisible(false);
        			new Login(customerId,password).setVisible(true);
                } 
                 }
            }else if(ae.getSource()==b2){
            	setVisible(false);
    			new Login(customerId,password).setVisible(true);
            }    
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }    
    public static void main(String[] args){
        new Signup3("","").setVisible(true);
    }
    
}
