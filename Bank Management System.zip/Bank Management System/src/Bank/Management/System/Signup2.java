package Bank.Management.System;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.Random;

public class Signup2 extends OutputScreenGUI implements ActionListener{
    
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l22;
    JButton b;
    JRadioButton r1,r2,r3,r4;
    JTextField t1,t2,t3;
    JComboBox c0,c1,c2,c3,c4,c5;
    String formno;
    String name;
    Signup2(String formno, String name){
        this.name=name;
        this.formno=formno;
    	ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/skyblue.jfif"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l0 = new JLabel(i3);
        l0.setBounds(0, 0, 960, 1080);
        add(l0);
        
        
        this.formno = formno;
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 2");
        
        l1 = new JLabel("Page 2: Additonal Details");
        l1.setFont(new Font("Raleway", Font.BOLD, 22));
        
        l2 = new JLabel("Religion:");
        l2.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l3 = new JLabel("Category:");
        l3.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l4 = new JLabel("Income:");
        l4.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l5 = new JLabel("Educational");
        l5.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l11 = new JLabel("Qualification:");
        l11.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l6 = new JLabel("Occupation:");
        l6.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l7 = new JLabel("PAN Number:");
        l7.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l8 = new JLabel("Aadhar Number:");
        l8.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l9 = new JLabel("Senior Citizen:");
        l9.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l10 = new JLabel("Existing Account:");
        l10.setFont(new Font("Raleway", Font.BOLD, 18));
        
        l12 = new JLabel("Form No:");
        l12.setFont(new Font("Raleway", Font.BOLD, 13));
        
        l13 = new JLabel(formno);
        l13.setFont(new Font("Raleway", Font.BOLD, 13));
        
        b = new JButton("Next");
        b.setFont(new Font("Raleway", Font.BOLD, 14));
        b.setBackground(Color.BLUE);
        b.setForeground(Color.WHITE);
        
        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 14));
        
        t2 = new JTextField();
        t2.setFont(new Font("Raleway", Font.BOLD, 14));
        
        r1 = new JRadioButton("Yes");
        r1.setFont(new Font("Raleway", Font.BOLD, 14));
        r1.setBackground(Color.WHITE);
        
        r2 = new JRadioButton("No");
        r2.setFont(new Font("Raleway", Font.BOLD, 14));
        r2.setBackground(Color.WHITE);
        
        ButtonGroup senior = new ButtonGroup();
        senior.add(r1);
        senior.add(r2);
        
        r3 = new JRadioButton("Yes");
        r3.setFont(new Font("Raleway", Font.BOLD, 14));
        r3.setBackground(Color.WHITE);
        
        r4 = new JRadioButton("No");
        r4.setFont(new Font("Raleway", Font.BOLD, 14));
        r4.setBackground(Color.WHITE);
        
        ButtonGroup account = new ButtonGroup();
        account.add(r3);
        account.add(r4);
        
        String religion[] = {"Hindu","Muslim","Sikh","Christian","Other"};
        c1 = new JComboBox(religion);
        c1.setBackground(Color.WHITE);
        c1.setFont(new Font("Raleway", Font.BOLD, 14));
        
        String category[] = {"General","OBC","SC","ST","Other"};
        c2 = new JComboBox(category);
        c2.setBackground(Color.WHITE);
        c2.setFont(new Font("Raleway", Font.BOLD, 14));
        
        String income[] = {"Null","<1,50,000","<2,50,000","<5,00,000","Upto 10,00,000","Above 10,00,000"};
        c3 = new JComboBox(income);
        c3.setBackground(Color.WHITE);
        c3.setFont(new Font("Raleway", Font.BOLD, 14));
        
        String education[] = {"Non-Graduate","Graduate","Post-Graduate","Doctrate","Others"};
        c4 = new JComboBox(education);
        c4.setBackground(Color.WHITE);
        c4.setFont(new Font("Raleway", Font.BOLD, 14));
        
        String occupation[] = {"Salaried","Self-Employmed","Business","Student","Retired","Others"};
        c5 = new JComboBox(occupation);
        c5.setBackground(Color.WHITE);
        c5.setFont(new Font("Raleway", Font.BOLD, 14));
        
        
        l22 = new JLabel("Account Type:");
        l22.setFont(new Font("Raleway", Font.BOLD, 18));
        String accountType[] = {"","Saving Account","Current Account","Fixed Deposit Account","Recurring Deposit Account"};
        c0 = new JComboBox(accountType);
        c0.setBackground(Color.WHITE);
        c0.setFont(new Font("Raleway", Font.BOLD, 14));
        
//        c0.setBounds(300,100,200,30);
//        l0.add(c0);
        
        c0.setBounds(350,580,200,30);
        l0.add(c0);
       
        l22.setBounds(100,580,200,30);
        l0.add(l22);
       
        setLayout(null);
        
        
        l12.setBounds(700,10,60,30);
        l0.add(l12);
        
        l13.setBounds(760,10,60,30);
        l0.add(l13);
        
        l1.setBounds(280,30,600,40);
        l0.add(l1);
        
        l2.setBounds(100,120,100,30);
        l0.add(l2);
        
        c1.setBounds(350,120,320,30);
        l0.add(c1);
        
        l3.setBounds(100,170,100,30);
        l0.add(l3);
        
        c2.setBounds(350,170,320,30);
        l0.add(c2);
        
        l4.setBounds(100,220,100,30);
        l0.add(l4);
        
        c3.setBounds(350,220,320,30);
        l0.add(c3);
        
        l5.setBounds(100,270,150,30);
        l0.add(l5);
        
        c4.setBounds(350,270,320,30);
        l0.add(c4);
        
        l11.setBounds(100,290,150,30);
        l0.add(l11);
        
        l6.setBounds(100,340,150,30);
        l0.add(l6);
        
        c5.setBounds(350,340,320,30);
        l0.add(c5);
        
        l7.setBounds(100,390,150,30);
        l0.add(l7);
        
        t1.setBounds(350,390,320,30);
        l0.add(t1);
        
        l8.setBounds(100,440,180,30);
        l0.add(l8);
        
        t2.setBounds(350,440,320,30);
        l0.add(t2);
        
        l9.setBounds(100,490,150,30);
        l0.add(l9);
        
        r1.setBounds(350,490,100,30);
        l0.add(r1);
        
        r2.setBounds(460,490,100,30);
        l0.add(r2);
        
        l10.setBounds(100,540,180,30);
        l0.add(l10);
        
        r3.setBounds(350,540,100,30);
        l0.add(r3);
        
        r4.setBounds(460,540,100,30);
        l0.add(r4);
        
        b.setBounds(700,600,100,30);
        l0.add(b);
        
        b.addActionListener(this);
        
        getContentPane().setBackground(Color.WHITE);     
        setSize(850,750);
        setLocation(0,0);
        setVisible(true);
        
        
        
    }
    
 
    
    public void actionPerformed(ActionEvent ae){
    	
     

    	String s1=(String)c0.getSelectedItem();
    	//String i="0";
        String religion = (String)c1.getSelectedItem(); 
        String category = (String)c2.getSelectedItem();
        String income = (String)c3.getSelectedItem();
        String education = (String)c4.getSelectedItem();
        String occupation = (String)c5.getSelectedItem();
        
        String pan = t1.getText();
        String aadhar = t2.getText();
        boolean a=pan.matches("[A-Z][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][A-Z]");

        boolean b=aadhar.matches("[2-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]");

        String scitizen = "";
        if(r1.isSelected()){ 
            scitizen = "Yes";
        }
        else if(r2.isSelected()){ 
            scitizen = "No";
        }
           
        String eaccount = "";
        if(r3.isSelected()){ 
            eaccount = "Yes";
        }else if(r4.isSelected()){ 
            eaccount = "No";
        }
        Random ran = new Random();
        long first7 = (ran.nextLong() % 90000000L) + 5040936000000000L;
        String customerId = "" + Math.abs(first7);

        long first3 = (ran.nextLong() % 9000L) + 1000L;
        String password = "" + Math.abs(first3);
        String TotalAmmount="0";
        try{
            if(t2.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Fill all the required fields");
            }
            else if(!a){
                JOptionPane.showMessageDialog(null, "Please enter valid Pan id");
            }
            else if(!b){
                JOptionPane.showMessageDialog(null, "Please enter valid Aadhar id");
            }
            else{
                Conn c1 = new Conn();
                //Intrest(customerId, s1,formno,name);
                String q1 = "insert into signup2 values('"+formno+"','"+religion+"','"+category+"','"+income+"','"+education+"','"+occupation+"','"+pan+"','"+aadhar+"','"+scitizen+"','"+eaccount+"')";
                String q2 = "insert into login1 values('"+formno+"','"+customerId+"','"+password+"','"+TotalAmmount+"')";
                c1.s.executeUpdate(q1);
                c1.s.executeUpdate(q2);
            
                ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("icon/skyblue.jfif"));
                Image i22 = i11.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
                ImageIcon i33 = new ImageIcon(i22);
                JLabel l0 = new JLabel(i33);
                l0.setBounds(0, 0, 960, 1080);
                add(l0);
                JOptionPane.showMessageDialog(null, "Customer ID: " + customerId + "\n Password: "+ password+"\n TotalAmmount:"+ TotalAmmount);
                new Signup3(formno,name).setVisible(true);
                setVisible(false);
            }
                
      
            
        }catch(Exception ex){
             ex.printStackTrace();
        }
    
               
    }
    


	public static void main(String[] args){
        new Signup2("","").setVisible(true);
    }
}
