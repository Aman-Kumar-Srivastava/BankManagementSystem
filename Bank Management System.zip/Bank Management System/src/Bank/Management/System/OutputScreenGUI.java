package Bank.Management.System;

	import java.awt.*;
	import java.awt.event.*;
	import javax.swing.*;
	import java.sql.*;
	import java.util.Random;

	public class OutputScreenGUI extends JFrame{
	  public OutputScreenGUI() {		
		  super.setTitle("Welcome to MyBank");
		  super.getContentPane().setBackground(Color.WHITE);
		  super.setSize(900,900);
		  super.setVisible(true);
	  }
	  
	public static void main(String[] args) {
		new OutputScreenGUI();
	}
	}
