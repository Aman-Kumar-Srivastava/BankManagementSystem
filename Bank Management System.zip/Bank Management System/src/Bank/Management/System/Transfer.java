package Bank.Management.System;
import javax.swing.*;
import java.awt.*;
import java. awt.event.*;
import java.sql.ResultSet;
import java.util.*;


public class Transfer extends WithdrawMoney implements ActionListener {
	
	JTextField amount, t1,t2;
	JButton TransferMoney, Back;
	String password;
	String customerId;
	ResultSet rs1,rs2;
	
	
	public Transfer(String customerId) {
		
		super();
		this.password = password;
		this.customerId=customerId;
		setLayout(null);
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/brown.jfif"));
		Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 900, 900);
        add(image); 
        
        
        JLabel text1 = new JLabel("Enter Your Account Number");
        text1.setForeground(Color.WHITE);
        text1.setFont(new Font("System", Font.BOLD, 20));
        text1.setBounds(100, 180, 400, 20);
        image.add(text1);
        
        JLabel text2 = new JLabel("Enter The Account Number to Transfer");
        text2.setForeground(Color.WHITE);
        text2.setFont(new Font("System", Font.BOLD, 20));
        text2.setBounds(100, 280, 400, 20);
        image.add(text2);
        
        
        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 22));
        t1.setBounds(100, 210, 350, 30);
        image.add(t1);
        
        t2 = new JTextField();
        t2.setFont(new Font("Raleway", Font.BOLD, 22));
        t2.setBounds(100, 310, 350, 30);
        image.add(t2);
        
        
        JLabel text0 = new JLabel("Enter The Amount to Transfer");
        text0.setForeground(Color.WHITE);
        text0.setFont(new Font("System", Font.BOLD, 20));
        text0.setBounds(100, 380, 400, 20);
        image.add(text0);
        
        amount = new JTextField();
        amount.setFont(new Font("Raleway", Font.BOLD, 22));
        amount.setBounds(100, 410, 350, 30);
        image.add(amount);
        
        
        TransferMoney = new JButton("Transfer");
        TransferMoney.setBounds(100, 480, 150, 35);
        TransferMoney.setFont(new Font("Raleway", Font.BOLD, 20));
        TransferMoney.addActionListener(this);
        image.add(TransferMoney);
        
        
        Back = new JButton("Back");
        Back.setBounds(300, 480, 150, 35);
        Back.setFont(new Font("Raleway", Font.BOLD, 20));
        Back.addActionListener(this);
        image.add(Back);
        
        
        setSize(900, 900);
        setLocation(0, 0);
        setVisible(true);
        }
	//we are using overriding here
	@Override
	  public String currentBalance(String s){	    	
		  	 String amount1 = amount.getText();
		  	 String balance="";
		  	 int c=0;
			   c =Integer.parseInt(s)-Integer.parseInt(amount1);
		      System.out.println(c);
		      balance=""+Integer.toString(c);
		      return balance;		      
		   }
	
	@Override
	public void actionPerformed(ActionEvent ae) {
		
		String custId1=t1.getText();
		String custId2=t2.getText();
		int a=0, b=0;
		String balance1="",balance2="";
		String transferredamount = amount.getText();
		try{
			
			if (ae.getSource() == Back) {
				setVisible(false);
				new Transactions("").setVisible(true);
				}
			else if (ae.getSource() == TransferMoney) {
				if(transferredamount.equals("")){
					JOptionPane.showMessageDialog(null, "PLEASE ENTER THE AMOUNT");
					}
				else{
					
					Date date = new Date();
					Conn c1 = new Conn();
					String query1 = "select * from login1 where customerId = '"+custId1+"'";
					//String query2 = "select * from login1 where customerId = '"+custId2+"'";
                    rs1 = c1.s.executeQuery(query1);
                    //rs2 = c1.s.executeQuery(query1);
                    if(!rs1.next()) {
                    	JOptionPane.showMessageDialog(null, "Incorrect Customer Id");
                    }
//                    else if(!rs2.next()) {
//                    	JOptionPane.showMessageDialog(null, "Incorrect Customer Id");
//                    }
                    else{
                    	 if(Integer.parseInt(rs1.getString("TotalAmmount"))< Integer.parseInt(transferredamount)) {
     						JOptionPane.showMessageDialog(null, "Insufficient Balance");
                         }
                    	 else {
//                    	a =Integer.parseInt(rs1.getString("TotalAmmount"))-Integer.parseInt(transferredamount);
//                        balance1=""+Integer.toString(a);
                    		 String s=(rs1.getString("TotalAmmount"));
                    		 balance1=currentBalance(s);
//                        b =Integer.parseInt(rs2.getString("TotalAmmount"))+Integer.parseInt(transferredamount);
//                        balance2=""+Integer.toString(b);
                        String q1 = "update login1 set TotalAmmount = '"+balance1+"' where customerId = '"+custId1+"'";
  					    String q2 = "insert into bank3 values('"+custId1+"', 'xxxx','Withdraw', '"+transferredamount+"')";
	                    c1.s.executeUpdate(q1);
	                    c1.s.executeUpdate(q2);
	                    
//	                    String q3 = "update login1 set TotalAmmount = '"+balance2+"' where customerId = '"+custId2+"'";
//  					    String q4 = "insert into bank3 values('"+custId2+"', 'xxxx','Withdraw', '"+transferredamount+"')";
//	                    c1.s.executeUpdate(q3);
//	                    c1.s.executeUpdate(q4);
	                    JOptionPane.showMessageDialog(null, "Rs. "+transferredamount+" Transfered Successfully"+ "\n Customer Id: "+customerId+"\n Current balance: "+balance1);
						//c1.s.executeUpdate("insert into bank3 values('"+password+"', '"+date+"','Transfer', '"+transferredamount+"')");
						setVisible(false);
						new Transactions("").setVisible(true);
                    	 }
                    }
				}
			}
		}
                    
					
		
		catch (Exception e) {
			System.out.println(e);
			}
		}
	public static void main(String[] args) {
		new Transfer("");
		}
	}
	
