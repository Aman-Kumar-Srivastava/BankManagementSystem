package Bank.Management.System;
import java.util.*;
import java.sql.*;
public class Authentication {
	private static Connection con = null;
    private static final String username = "root";
    private static final String password = "Captain@2004";
    private static final String url = "jdbc:mysql://localhost:3306/BMS";
    private static final String className = "com.mysql.cj.jdbc.Driver";
    private static final String tableName = "customer";
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int pin = 0;
	
	try {
		Class.forName(className);
        con = DriverManager.getConnection(url,username,password);
        Statement stmt=con.createStatement();
        System.out.println("Enter your customer ID:");
        int id= sc.nextInt();
        System.out.println("Enter Your Pin");
        int p=sc.nextInt();
        String sql = "Select pin from " + tableName + " where CustomerId = " + id;
        ResultSet a = stmt.executeQuery(sql);
       while( a.next()) {
        pin=a.getInt("pin");
       }
	if(pin==p) {
		System.out.println("User Exist");
	}
	else {
		System.out.println("Invalid Crediantials");
	}
	
	}
	catch (Exception e) {
		System.out.println(e);
	}
	
}
}


class Intrest extends Signup2{
	   ////	        String s=(String)c0.getSelectedItem();
////     String i;
Intrest(String customerId, String s, String formno, String name) throws SQLException{
 	   super(formno, name);
// 	 this.i=i;
//     	  this.s=s;
 	   String i;
     	 if(s.equals("Saving Account"))
     	    i= "5";
     	 else if(s.equals("Current Account"))
     		 i="6";
     	 else if(s.equals("Fixed Deposit Account"))
     		 i="7";
     	 else
     		 i="8";
     	 System.out.println(i);
     	 Conn c1=new Conn();
     	 String q0= "insert into rate values('"+customerId+"','"+s+"','"+i+"')";
     	    c1.s.executeUpdate(q0);
     }
      

 }
