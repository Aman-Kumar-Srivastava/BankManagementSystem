package Bank.Management.System;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Login extends OutputScreenGUI implements ActionListener{
	
	JButton login, reset, signup;
	JTextField custIdTextField;
	JPasswordField passTextField;
	  String TotalAmmount;
	  String customerId;
	  String password;
	 Login(String customerId, String password){
		 this.TotalAmmount=TotalAmmount;
		 this.customerId=customerId;
		 this.password=password;
		 //setTitle("Welcome To jk MyBank");
    		ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("icon/skyblue.jfif"));
	        Image i22 = i11.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
	        ImageIcon i33 = new ImageIcon(i22);
	        JLabel l0 = new JLabel(i33);
	        l0.setBounds(0, 0, 960, 1080);
	        add(l0);
		 setLayout(null);
		 ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/banks.jpg"));
		 Image i2=i1.getImage().getScaledInstance(150,150, Image.SCALE_DEFAULT);
		 ImageIcon i3=new ImageIcon(i2);
		 JLabel label=new JLabel(i3);
		 label.setBounds(150,10,100,100);
		 l0.add(label);
		 
		 JLabel text=new JLabel("Welcome to Bank");
		 text.setFont(new Font("Osward", Font.BOLD,38));
		 text.setBounds(300,40,400,40);
		 l0.add(text);
		 		 
		 JLabel custId=new JLabel("CUSTOMER ID:");
		 custId.setFont(new Font("Osward", Font.BOLD,28));
		 custId.setBounds(120,150,250,30);
		 l0.add(custId);
		 
		 custIdTextField=new JTextField();
		 custIdTextField.setBounds(350,150,250,30);
		 custIdTextField.setFont(new Font("Arial", Font.BOLD,14));
		 add(custIdTextField);
		 
		 JLabel pass=new JLabel("PASSWORD:");
		 pass.setFont(new Font("Osward", Font.BOLD,28));
		 pass.setBounds(120,220,250,30);
		 l0.add(pass);
		 
		 passTextField=new JPasswordField ();
		 passTextField.setBounds(350,220,250,30);
		 passTextField.setFont(new Font("Arial", Font.BOLD,14));
		 l0.add(passTextField);
		 		 
		 login=new JButton("SIGN IN");
		 login.setBounds(350,300,100,30);
		 login.setBackground(Color.BLUE);
		 login.setForeground(Color.WHITE);
		 login.addActionListener(this);
		 l0.add(login);
		 
		 reset=new JButton("RESET");
		 reset.setBounds(500,300,100,30);
		 reset.setBackground(Color.BLUE);
		 reset.setForeground(Color.WHITE);
		 reset.addActionListener(this);
		 l0.add(reset);
		 
		 signup=new JButton("CREATE NEW ACCOUNT");
		 signup.setBounds(350,350,250,30);
		 signup.setBackground(Color.BLUE);
		 signup.setForeground(Color.WHITE);
		 signup.addActionListener(this);
		 l0.add(signup);
//now we are inherting this feautre from OutputScreenGUI		 		 
	//	 getContentPane().setBackground(Color.WHITE);
		 setSize(800,480);
//		 setVisible(true);
//		 setLocation(0,0);
     }
	 public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==reset)   {
			custIdTextField.setText("");
			passTextField.setText("");
		}	else if(ae.getSource()==login) {
			Conn c3 = new Conn();
			String custId = custIdTextField.getText();
			String password = passTextField.getText();
			String query = "select * from login1 where customerId = '"+custId+"' and password = '"+password+"'";
			try {
				ResultSet rs = c3.s.executeQuery(query);
				if (rs.next() ) {
					setVisible(false);
					new Transactions(customerId).setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "Incorrect Customer Id or Password");
				}
			}catch(Exception e) {
				System.out.println(e);
			}
			
		}	else if(ae.getSource()==signup) {
				setVisible(false);
				new Signup1().setVisible(true);
		}
	 }
	public static void main(String args[]) {
		new Login("","");
	}
}
