package Bank.Management.System;

import java.sql.*;
//import java.sql.DriverManager;
public class MySQLConnection {
public Connection getConnection() {
	Connection connection=null;
	System.out.println(" ");
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/customer","root","Captain@2004");
	} 
	catch (ClassNotFoundException e){
	e.printStackTrace();	
	} 
	catch (SQLException e) {
		e.printStackTrace();
	}
	return connection;
}
}
