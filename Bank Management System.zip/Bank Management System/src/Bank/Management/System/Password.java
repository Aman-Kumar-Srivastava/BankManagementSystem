package Bank.Management.System;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Password extends OutputScreenGUI  implements ActionListener{
    
    JPasswordField t0,t1,t2;
    JButton b1,b2;                               
    JLabel l1,l12,l2,l3;
    String password;
    Password(String password){
        this.password = password;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/brown.jfif"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l4 = new JLabel(i3);
        l4.setBounds(0, 0, 960, 1080);
        add(l4);
        
        l1 = new JLabel("CHANGE YOUR PASSWORD");
        l1.setFont(new Font("System", Font.BOLD, 16));
        l1.setForeground(Color.WHITE);
        
        l12 = new JLabel("Old PASSWORD:");
        l12.setFont(new Font("System", Font.BOLD, 16));
        l12.setForeground(Color.WHITE);
        
        l2 = new JLabel("New PASSWORD:");
        l2.setFont(new Font("System", Font.BOLD, 16));
        l2.setForeground(Color.WHITE);
        
        l3 = new JLabel("Re-Enter New PASSWORD:");
        l3.setFont(new Font("System", Font.BOLD, 16));
        l3.setForeground(Color.WHITE);
        
        t0 = new JPasswordField();
        t0.setFont(new Font("Raleway", Font.BOLD, 25));
        
        t1 = new JPasswordField();
        t1.setFont(new Font("Raleway", Font.BOLD, 25));
        
        t2 = new JPasswordField();
        t2.setFont(new Font("Raleway", Font.BOLD, 25));
        
        b1 = new JButton("CHANGE");
        b2 = new JButton("BACK");
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        
        setLayout(null);
        
        l1.setBounds(280,300,800,35);
        l4.add(l1);
        l12.setBounds(120,350,150,35);
        l4.add(l12);
        l2.setBounds(120,390,150,35);
        l4.add(l2);
        
        l3.setBounds(120,440,250,35);
        l4.add(l3);
        
        t0.setBounds(350,350,180,25);
        l4.add(t0);
        
        t1.setBounds(350,390,180,25);
        l4.add(t1);
        
        t2.setBounds(350,440,180,25);
        l4.add(t2);
        
        b1.setBounds(390,500,150,35);
        l4.add(b1);
        
        b2.setBounds(390,545,150,35);
        l4.add(b2);
        
        setSize(960,1080);
        setLocation(0,0);
        //setUndecorated(false);
        setVisible(true);
    
    }
    
    public void actionPerformed(ActionEvent ae){
        try{
        	String opass=t0.getText();
            String npass = t1.getText();
            String rpass = t2.getText();
            
            if(!npass.equals(rpass)){
                JOptionPane.showMessageDialog(null, "Entered PASSWORD does not match");
                return;
            }
            
            if(ae.getSource()==b1){
                if (t1.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Enter New PASSWORD");
                }
                if (t2.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Re-Enter new PASSWORD");
                }
                
                Conn c1 = new Conn();
                String q1 = "update bank3 set password = '"+rpass+"' where password = '"+opass+"' ";
                String q2 = "update login1 set password = '"+rpass+"' where password = '"+opass+"' ";
               

                c1.s.executeUpdate(q1);
                c1.s.executeUpdate(q2);

                JOptionPane.showMessageDialog(null, "PASSWORD changed successfully");
                setVisible(false);
                new Transactions(rpass).setVisible(true);
            
            }else if(ae.getSource()==b2){
                new Transactions(password).setVisible(true);
                setVisible(false);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args){
        new Password("").setVisible(true);
    }
}
