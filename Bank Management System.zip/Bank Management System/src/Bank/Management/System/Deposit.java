package Bank.Management.System;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;

public class Deposit extends WithdrawMoney implements ActionListener{
    
    JTextField t1,t2,t3,t4;
    JButton b1,b2,b3;
    JLabel l1,l2,l3,l4;
    String customerId;
    String password;
    Deposit(String customerId){
        this.customerId=customerId;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/brown.jfif"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0, 0, 900, 900);
        add(l3);
        
        l2 = new JLabel(" BANK MANAGEMENT SYSTEM  ");
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("System", Font.BOLD, 28));
        l2.setBounds(210, 120, 500, 25);
        l3.add(l2);

        l1 = new JLabel("Enter Deposit Amount");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 20));
        
        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 28));
        
   //     t3 = new JTextField();
     //   t3.setFont(new Font("Raleway", Font.BOLD, 28));
        
        l4 = new JLabel("Enter Account Number");
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("System", Font.BOLD, 20));
        
        t4 = new JTextField();
        t4.setFont(new Font("Raleway", Font.BOLD, 28));
       
        b1 = new JButton("DEPOSIT");
        b2 = new JButton("BACK");
        
        setLayout(null);
        
        l1.setBounds(140,320,400,20);
        l3.add(l1);
        
        t1.setBounds(400,320,320,25);
        l3.add(t1);
        
      //  t3.setBounds(500,320,320,25);
      //    l3.add(t3);
        
        l4.setBounds(140,220,400,20);
        l3.add(l4);
        
        t4.setBounds(400,220,320,25);
        l3.add(t4);
        
        b1.setBounds(370,460,150,30);
        l3.add(b1);
        
        b2.setBounds(370,500,150,30);
        l3.add(b2);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        
        setSize(960,900);
        //setUndecorated(false);
        setLocation(0,0);
        setVisible(true);
    }
    
    //we are using here overriding
    @Override
    public  String currentBalance(String s){		    	
	  	 String amount = t1.getText();
	  	 String balance="";
	  	 int c=0;
		 c =Integer.parseInt(s)+Integer.parseInt(amount);
	     balance=""+Integer.toString(c);
	     return balance;		      
	   }
    
    public void actionPerformed(ActionEvent ae){
            if(ae.getSource()==b1){
            	String ammount = t1.getText();
            	String customerId = t4.getText();
            	int c=0;
            	String balance="";
                if(t1.equals("")){
                    JOptionPane.showMessageDialog(null, "Please enter the Amount to you want to Deposit");
                }else{
                	 String query = "select * from login1 where customerId = '"+customerId+"'";                
                	try {
                		
	                    Conn c1 = new Conn(); 
	        				ResultSet rs = c1.s.executeQuery(query);
	        				if (!rs.next() ) {
	        					JOptionPane.showMessageDialog(null, "Incorrect Customer Id");
	        				} else {
//	        					 c =Integer.parseInt(ammount)+Integer.parseInt(rs.getString("TotalAmmount"));
//                                 System.out.println(c);
//                                 balance=""+Integer.toString(c);
	        					String s=(rs.getString("TotalAmmount"));
	                    		 balance=currentBalance(s);
	        					  String q2 = "update login1 set TotalAmmount = '"+balance+"' where customerId = '"+customerId+"'";
	        					  String q1 = "insert into bank3 values('"+customerId+"', 'xxxx','Deposit', '"+ammount+"')";
	      	                    c1.s.executeUpdate(q1);
	      	                    c1.s.executeUpdate(q2);
	      	                    JOptionPane.showMessageDialog(null, "Rs. "+ammount+" Deposited Successfully"+ "\n Customer Id: "+customerId+"\n Current balance: "+balance);
	      	                    setVisible(false);
	      	                    new Transactions(customerId).setVisible(true);
	                      	} 

	        				}
	                        catch(Exception e) {
                		System.out.println(e);
                	}
                }
            }else if(ae.getSource()== b2){
                setVisible(false);
                new Transactions(customerId).setVisible(true);
            }
        }
            
    
    public static void main(String[] args){
        new Deposit("").setVisible(true);
    }
}