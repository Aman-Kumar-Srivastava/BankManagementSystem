package Bank.Management.System;

import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import java.util.*;
import java.util.Date;

class BalanceEnquiry extends OutputScreenGUI  implements ActionListener {

    JTextField t1, t2,t4;
    JButton submit, back;
    JLabel l1, l2, l3,l4;
    String customerId;
    BalanceEnquiry(String customerId) {
        this.customerId = customerId;
        
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/brown.jfif"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l0 = new JLabel(i3);
        l0.setBounds(0, 0, 960, 1080);
        add(l0);
        
        l4 = new JLabel("Enter Account Number");
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("System", Font.BOLD, 20));
        
        t4 = new JTextField();
        t4.setFont(new Font("Raleway", Font.BOLD, 28));
        
        
        back = new JButton("BACK");
        back.addActionListener(this);
        back.setBounds(390, 600, 150, 35);
        l0.add(back);  
        
        submit = new JButton("SUBMIT");
        submit.addActionListener(this);
        submit.setBounds(390, 550, 150, 35);
        l0.add(submit); 
       
        
        setLayout(null);
         
        l4.setBounds(100,320,400,20);
        l0.add(l4);
        
        t4.setBounds(360,320,320,25);
        l0.add(t4);
 
        submit.addActionListener(this);
        back.addActionListener(this);

        setSize(960, 1080);
       // setUndecorated(true);
        setLocation(0, 0);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
    	int balance = 0;
		String customerId = t4.getText();
    	try {
    	if(ae.getSource()==submit) {
    		
            if(t4.equals("")){
                JOptionPane.showMessageDialog(null, "Please enter the customerId");
            }else {
            	String query = "select * from login1 where customerId = '"+customerId+"'";
            		
            	    Conn c1 = new Conn();
            	    ResultSet rs = c1.s.executeQuery(query);
    				if (!rs.next()) {
    					JOptionPane.showMessageDialog(null, "Incorrect Customer Id");
    				} else {
    					 DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
                         LocalDateTime now=LocalDateTime.now();
                         String now1 = now.format(dtf);
                                 balance += Integer.parseInt(rs.getString("TotalAmmount"));

                         JOptionPane.showMessageDialog(null, "Your Current Account balance is Rs "+ balance + "\n Date and time: " + now1);
                         
     	                new Transactions(customerId).setVisible(true);
     	                setVisible(false);
    				}
    				
            	}         
                
    		
    }
    	else if(ae.getSource()== back){
            setVisible(false);
            new Transactions(customerId).setVisible(true);
        }
    }
    	catch(Exception e){
        	System.out.print(e);
        }
}

    public static void main(String[] args) {
        new BalanceEnquiry("").setVisible(true);
    }
}


