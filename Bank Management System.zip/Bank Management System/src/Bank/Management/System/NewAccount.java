package Bank.Management.System;

	import javax.swing.*;  //Used for JFrame class
	import java.awt.*;  // Used bcz color class is inside awt  package
	import java.awt.event.*;

	public class NewAccount extends JFrame implements ActionListener{

	    
	    JTextField nameTextField, addressTextField, phonenoTextField, accounttypeTextField ;
	    JButton submit;
	    // Constructor
	    NewAccount(){ 
	        
	        
	        setTitle ("Bank Management System");
	        setLayout(null);
	        
	        //Image code 1 starts
	        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo2.jpg"));
	        Image i2 = i1.getImage().getScaledInstance(400, 600, Image.SCALE_DEFAULT);
	        ImageIcon i3 = new ImageIcon(i2);
	        JLabel label = new JLabel(i3);
	        label.setBounds(10,20,400, 600);
	        add(label);
	        
	        //Text 1
	        
	        JLabel text = new JLabel("New User Form");
	        text.setFont(new Font("Osward", Font.BOLD,38));
	        text.setBounds(420, 50, 300, 60);
	        add(text); 
	        
	        //Text 2
	        
	        JLabel text2 = new JLabel("Name");
	        text2.setFont(new Font("Times New Roman", Font.BOLD,20));
	        text2.setBounds(430, 150, 150, 60);
	        add(text2);
	        
	        nameTextField = new JTextField();
	        nameTextField.setBounds(430,200,150,30);
	        add(nameTextField);
	        
	        //Text 3
	        
	        JLabel text3 = new JLabel("Address");
	        text3.setFont(new Font("Times New Roman", Font.BOLD,20));
	        text3.setBounds(430, 230, 300, 60);
	        add(text3);
	        
	        addressTextField = new JTextField();
	        addressTextField.setBounds(430,280,150,30);
	        add(addressTextField);
	        
	        //Text 4
	        
	        JLabel text4 = new JLabel("Phone no.");
	        text4.setFont(new Font("Times New Roman", Font.BOLD,20));
	        text4.setBounds(430, 300, 300, 60);
	        add(text4);
	        
	        phonenoTextField = new JTextField();
	        phonenoTextField.setBounds(430,350,150,30);
	        add(phonenoTextField);
	        
	        //Text 5
	        
	        JLabel text5 = new JLabel("Account Type");
	        text5.setFont(new Font("Times New Roman", Font.BOLD,20));
	        text5.setBounds(430, 370, 420, 60);
	        add(text5);
	        
	        String valAcctype[] = {"Savings"," Current"};
	        JComboBox accounttype = new JComboBox(valAcctype);
	        accounttype.setBounds(430,420, 150, 40);
	        add(accounttype);
	        
	        accounttypeTextField = new JTextField();
	        accounttypeTextField.setBounds(430,420,150,30);
	        add(accounttypeTextField);
	        
	        //Submit Button
	       submit = new JButton("SUBMIT");
	       submit.setBounds(580,500,150,30);
	       submit.addActionListener(this);
	       add(submit);
	        
	        
	        getContentPane().setBackground(Color.WHITE);  
	        setSize(800, 680);
	        setVisible(true);
	        setLocation(450, 200);
	        
	    }
	    public void actionPerformed(ActionEvent ae){
	      
	    }
	    
	    
	    public static void main(String[] args) {
	        new NewAccount();       //Object creation
	    }
	}

