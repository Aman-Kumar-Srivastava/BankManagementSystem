package Bank.Management.System;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Transactions extends OutputScreenGUI  implements ActionListener{
    JLabel l1;
    JButton b1,b2,b3,b4,b5,b6,b7;
    String password;
    String TotalAmmount;
    String customerId;
    Transactions(String customerId){
        this.password = password;
        this.TotalAmmount=TotalAmmount;
        this.customerId=customerId;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/brown.jfif"));
        Image i2 = i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l2 = new JLabel(i3);
        l2.setBounds(0, 0, 900, 900);
        add(l2);
        
        l1 = new JLabel("Please Select Your Transaction");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 28));
        
       
        b1 = new JButton("ADD MONEY");
        b2 = new JButton("CASH WITHDRAWL");
        b3 = new JButton("TRANSFER MONEY");
        b4 = new JButton("MINI STATEMENT");
        b5 = new JButton("PASSWORD CHANGE");
        b6 = new JButton("BALANCE ENQUIRY");
        b7 = new JButton("EXIT");
        
        setLayout(null);
        
        l1.setBounds(215,100,700,35);
        l2.add(l1);
        
        b1.setBounds(150,200,250,35);
        l2.add(b1);
        
        b2.setBounds(420,200,250,35);
        l2.add(b2);
        
        b3.setBounds(150,300,250,35);
        l2.add(b3);
        
        b7.setBounds(330,500,150,35);
        l2.add(b7);
        
        b5.setBounds(420,300,250,35);
        l2.add(b5);
        
        b6.setBounds(150,400,250,35);
        l2.add(b6);
        
        b4.setBounds(420,400,250,35);
        l2.add(b4);
        
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
        
        
        setSize(900,900);
		setLocation(0,0);
        //setUndecorated(false);
        setVisible(true);   
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1){ 
            setVisible(false);
            new Deposit(password).setVisible(true);
        }else if(ae.getSource()==b2){ 
            setVisible(false);
            new Withdrawl(password).setVisible(true);
        }else if(ae.getSource()==b3){ 
            setVisible(false);
            new Transfer(customerId).setVisible(true);
        }else if(ae.getSource()==b4){ 
        	setVisible(false);
            new MiniStatement(password).setVisible(true);
        }else if(ae.getSource()==b5){ 
            setVisible(false);
            new Password(password).setVisible(true);
        }else if(ae.getSource()==b6){ 
            this.setVisible(false);
            new BalanceEnquiry(customerId).setVisible(true);
        }else if(ae.getSource()==b7){ 
        	setVisible(false);
			new Login(customerId,password).setVisible(true);
        }
    }
    
    public static void main(String[] args){
        new Transactions("").setVisible(true);
    }
}