package Bank.Management.System;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
public class ChequebookAndCard extends OutputScreenGUI  {
	 JLabel l1,l2,l3,l4,l5,l6;
	 String customerId;
	 String ChequeBookNo;
	 String DebitCardNo;
	 String CreditCardNo;
	 String name;
	ChequebookAndCard(String customerId, String ChequeBookNo, String DebitCardNo, String CreditCardNo, String name){
		this.customerId = customerId;
		this.ChequeBookNo = ChequeBookNo;
		this.DebitCardNo = DebitCardNo;
		this.CreditCardNo = CreditCardNo;
		this.name=name;
	setTitle("ISSUE OF CARD/CHEQUE-BOOK");
    ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/skyblue.jfif"));
    Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
    ImageIcon i3 = new ImageIcon(i2);
    JLabel l0 = new JLabel(i3);
    l0.setBounds(0, 0, 960, 1080);
    add(l0);
    
    setLayout(null);
    
    l1 = new JLabel(name);
    l1.setFont(new Font("Raleway", Font.BOLD, 18));
    
    l1.setBounds(300,120,200,30);
    l0.add(l1);
    
    l2 = new JLabel(ChequeBookNo);
    l2.setFont(new Font("Raleway", Font.BOLD, 18));
    
    l2.setBounds(100,320,200,30);
    l0.add(l2);
    
	 ImageIcon i11=new ImageIcon(ClassLoader.getSystemResource("icon/chewqu1.jpg"));
	 Image i22=i11.getImage().getScaledInstance(626,300, Image.SCALE_DEFAULT);
	 ImageIcon i33=new ImageIcon(i22);
	 JLabel label=new JLabel(i33);
	 label.setBounds(0,0,700,400);
	 l0.add(label);
	 
	

	 l3 = new JLabel(DebitCardNo);
     l3.setFont(new Font("Raleway", Font.BOLD, 22));
     
     l3.setBounds(550,470,200,30);
     l0.add(l3);
     
     l4 = new JLabel("DEBIT CARD");
     l4.setFont(new Font("Raleway", Font.BOLD, 22));
     
     l4.setBounds(650,420,200,30);
     l0.add(l4);
     
     l5 = new JLabel("08/25");
     l5.setFont(new Font("Raleway", Font.BOLD, 22));
     
     l5.setBounds(680,550,200,30);
     l0.add(l5);
     
     l6 = new JLabel("VALID");
     l6.setFont(new Font("Raleway", Font.BOLD, 10));
     
     l6.setBounds(645,547,200,30);
     l0.add(l6);
     
     l6 = new JLabel("THRU");
     l6.setFont(new Font("Raleway", Font.BOLD, 10));
     
     l6.setBounds(645,557,200,30);
     l0.add(l6);
     
	 ImageIcon i12=new ImageIcon(ClassLoader.getSystemResource("icon/card11.jpg"));
	 Image i23=i12.getImage().getScaledInstance(400,300, Image.SCALE_DEFAULT);
	 ImageIcon i34=new ImageIcon(i23);
	 JLabel label1=new JLabel(i34);
	 label1.setBounds(350,350,700,300);
	 l0.add(label1);
	  
//	  getContentPane().setBackground(Color.WHITE);
//      setSize(950,850);
//      setLocation(0,0);
//      setVisible(true);
	}
    
    public static void main(String[] args){
        new ChequebookAndCard("","","","","").setVisible(true);
    }
    
}
