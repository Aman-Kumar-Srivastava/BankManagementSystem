package com.springcore.ci;

public class Certi {
	private String cname;
	private String cid;
	public Certi(String cname, String cid) {
		super();
		this.cname = cname;
		this.cid = cid;
	}
	@Override
	public String toString() {
		return "Certi [cname=" + cname + ", cid=" + cid + "]";
	}
	
}
