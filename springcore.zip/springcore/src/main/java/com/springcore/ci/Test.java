package com.springcore.ci;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
;

public class Test {
public static void main(String args[]) {
     ApplicationContext c=new ClassPathXmlApplicationContext("com/springcore/ci/ciconfig.xml");
//     Person s1=(Person) c.getBean("person");
//     System.out.println(s1);
	
   Addition s2=(Addition) c.getBean("add");
   System.out.println(s2);
   s2.doSum();
    
}
}
