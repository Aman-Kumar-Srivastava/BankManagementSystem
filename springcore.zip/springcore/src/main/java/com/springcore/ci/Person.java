package com.springcore.ci;

import java.util.List;

public class Person {
private String name;
private String id;
private Certi cer;
private List<String> list;

public Person(String name, String id, Certi cer, List<String> list) {
	this.name=name;
	this.id=id;
	this.cer=cer;
	this.list=list;
}


@Override
public String toString() {
	return "Person [name=" + name + ", id=" + id + ", cer=" + cer + ",list="+list+"]";
}


 


}
