package com.liquorShop.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.liquorShop.entity.User;


@Repository
public interface UserRepo extends CrudRepository<User, Long>{
	
        public boolean existsByEmailAndPassword(String email, String passowrd);
	 
	    public User findUserByEmail(String email);

}

