package com.liquorShop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.liquorShop.entity.User;
import com.liquorShop.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private UserService service;
	
	@PostMapping("/signUp")
	public User saveUsers(@RequestBody User user) {
		return service.saveUsers(user);
	}
	
	public String email;
	public String userPassword;
	public boolean res=false;
	
	@GetMapping("/login/{email}/{password}")
	public String findUser(@PathVariable("email") String e,@PathVariable("password") String p){
		res=service.getExistUserByEmailAndPassword(e, p);
		System.out.println(res);
		if(res==true) {		
			System.out.println(e+"--"+p);
			email=e;
		    userPassword=p;
			return "next-page= "+e+"--"+p;//sucessfully return to home page
		}
		return "redirect: /homepage";// unsucessful attempt
	}
	
	
	@GetMapping("/account")
	public User fetchUserDetails() {
		if(res==true) {
			System.out.println(email);
			User u=service.fetchUserDetail(email);
			System.out.println(u.toString());
			return u;
		}
		else {
			System.out.println("please login");
			return null;
		}
	}
	
	@PostMapping("/changepassword/{password}/{newpassword}")
	String changePassword(@RequestBody String r, @PathVariable("password") String password, @PathVariable("newpassword") String newPassword) {
		System.out.println(res+" "+email);
		User user=service.fetchUserDetail(this.email);
		System.out.println(user.toString());
	if(res==true) {
			if(userPassword.equals(password)) {
				System.out.println(password+" getpass "+email);
			User user1=this.service.fetchUserDetail(this.email);
			System.out.println(user1.toString());
		    service.changePassword(user, newPassword);
			}
			else {
				System.out.println("incorrect password");
				return "incorrect password";
			}
			
		return "account-page";
		}
		else
			return "please login";
	}
}
