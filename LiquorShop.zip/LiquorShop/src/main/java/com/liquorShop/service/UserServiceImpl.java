package com.liquorShop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.liquorShop.entity.User;
import com.liquorShop.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserRepo repo;
	@Override
	public boolean getExistUserByEmailAndPassword(String email, String password) {
		
		return repo.existsByEmailAndPassword(email, password);
	}
//	@Autowired
//	private UserRepo userRepo;

	@Override
	public User saveUsers(User user) {
		return repo.save(user);
	}

	@Override
	public void changePassword(User user, String password) {
		user.setPassword(password);
		repo.save(user);
		
	}


	@Override
	public User fetchUserDetail(String email) {
		System.out.println(email);
		return repo.findUserByEmail(email);
		
	}
	
}
