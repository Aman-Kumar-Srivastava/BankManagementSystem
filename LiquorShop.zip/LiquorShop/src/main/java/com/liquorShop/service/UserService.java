package com.liquorShop.service;

import org.springframework.stereotype.Service;

import com.liquorShop.entity.User;

@Service
public interface UserService {

	User saveUsers(User user);
	boolean getExistUserByEmailAndPassword(String email, String password);
	
	User fetchUserDetail(String email);
	void changePassword(User user, String password);
}
