package com.liquorShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiquorShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiquorShopApplication.class, args);
	}

}
