package demo;
import java.util.*;

public class ComapreByKey {
	public static void main(String args[]) {
		Map<Integer,String> map = new HashMap<Integer,String>();

		map.put(100, "Amit");
		map.put(101, "Vijay");
		map.put(102, "Rahul");
		
		System.out.println("Initial hash map " + map);
		
		Map<Integer, String> new_map = new HashMap<Integer, String>();
		new_map.putAll(map);
		
		System.out.println("New HashMap " + new_map);
		
		new_map.putIfAbsent(301, "Naruto");
		new_map.putIfAbsent(302, "sasuke");
		
		System.out.println("After mapping the new value " + new_map);
		
		
		
		
	}


}
 