//case1:
package demo;
import  java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.io.IOException;

class A implements Serializable{
	int i;
	public A(int i) {
		this.i = i;
	}
	
}
class B extends A{
	int j;
	public B(int i, int j) {
		super(i);
		this.j = j;
	}
}

public class Serialization {

	public static void main(String[] args) {
		try {
			B b1 = new B(200, 400);
			System.out.println("i = " + " " + b1.i);
			System.out.println("j = " + " "+ b1.j);
			FileOutputStream fos = new FileOutputStream("abc.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(b1);
			oos.close();
			fos.close();
			System.out.println("The object has been Serialized");
			
			
			
			
		}
		catch (IOException e) {
			System.out.println("an error occured");
			e.printStackTrace();
		}
		

	}

}

