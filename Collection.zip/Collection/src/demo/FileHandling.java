package demo;
import java.io.File;
import java.io.IOException;

public class FileHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File obj = new File("MyFile.txt");
			if(obj.createNewFile()) {
				System.out.println("File Created : "+ " "+ obj.getName());
				
			}
			else {
				System.out.println("File already exists");
				
			}
			
		}
		catch (IOException e) {
			System.out.println("an error occured");
			e.printStackTrace();
			
		}
			
		
		
		

	}

}
