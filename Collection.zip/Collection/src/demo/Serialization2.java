//case2:

package demo;
import java.io.Serializable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

class superclass{
	int i;
	public superclass(int i) {
		this.i = i;
	}
	public superclass() {
		i = 50;
		System.out.println("superclass constructor called");
	}
}
class subclass extends superclass implements Serializable{
	int j;
	public subclass(int i, int j) {
		super(i);
		this.j = j;
	}
}

public class Serialization2 {

	public static void main(String[] args) throws ClassNotFoundException {
		try {
			subclass b2 = new subclass(2,4);
			System.out.println("i = " + b2.i);
			System.out.println("j = " + b2.j);
			FileOutputStream fos = new FileOutputStream("abc2.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(b2);
			oos.close();
			fos.close();
			System.out.println("The object has been serialized");
			FileInputStream fis = new FileInputStream("abc2.txt");
            ObjectInputStream ois = new ObjectInputStream(fis);
            subclass b3 = (subclass) ois.readObject();
            ois.close();
            fis.close();
            System.out.println("The object has been deserialized");
            System.out.println("i = " + b3.i);
            System.out.println("j = " + b3.j);
		}
		catch (IOException e) {
			System.out.println("error");
			e.printStackTrace();
		}
		
		
		
		
		

	}

}
