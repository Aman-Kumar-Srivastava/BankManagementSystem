package demo;

import java.util.Comparator;

public class Employee {
     int empId;
     String name;
    int salary;
    public Employee(int empId, String name, int salary) {
        this.empId = empId;
        this.name = name;
        this.salary = salary;
    }
    public int getEmpId() {
        return empId;
    }
    public void setEmpId(int empId) {
        this.empId = empId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSalary() {
        return salary;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
}
class Sortbyname implements Comparator<Employee> {
	 
    
    public int compare(Employee a, Employee b)
    {
 
        return a.name.compareTo(b.name);
    }
}
class Sortbysalary implements Comparator<Employee> {
	 
    
    public int compare(Employee a, Employee b)
    {
 
        return a.salary - b.salary;
    }
}
class SortbyempId implements Comparator<Employee> {
	 
    
    public int compare(Employee a, Employee b)
    {
 
        return a.empId - b.empId;
    }
}