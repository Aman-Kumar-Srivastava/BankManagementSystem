package demo;
import java.util.*;

public class ArrayListDemo {
	List<Employee> emp=new ArrayList<>();

    public void addEmployee(Employee employee) {
        emp.add(employee);
    }

    public void removeEmployeebyId(int id) {
           for(Employee e:emp) {
               if(e.getEmpId()==id) {
                   emp.remove(e);
               }
           }
           showEmployeeList();
       }

    public void removeEmployeebyName(String name) {
           for(Employee e:emp) {
               if(e.getName()==name) {
                   emp.remove(e);
               }
           }
           showEmployeeList();
       }

       public void showEmployeeList() {
           for(Employee employee:emp) {
               System.out.println(employee.getEmpId()+" "+employee.getName()+" "+ employee.getSalary());
           }




   }

       public void searchbyName(String name) {
           for(Employee employee:emp) {
               if(employee.getName().equals(name)) {
                   System.out.println(employee.getEmpId()+" "+ employee.getSalary());
               }
           }
       }
       public void searchbyId(int id) {
           for(Employee employee:emp) {
               if(employee.getEmpId()==id) {
                   System.out.println(employee.getName());
               }
           }
       }



   





   public static void main(String[] args) {
       ArrayListDemo m=new ArrayListDemo();

       m.addEmployee(new Employee(103,"Ankit",62346));
       m.addEmployee(new Employee(104,"Aniket",52346));
       m.addEmployee(new Employee(106,"Ishika",42346));
       m.addEmployee(new Employee(109,"Yash",32346));



       m.showEmployeeList();
       System.out.println("---------------");

       m.removeEmployeebyId(106);
       System.out.println("---------------");





       m.searchbyName("Yash");
       System.out.println("---------------");
       m.searchbyId(104);
       System.out.println("---------------");
       Collections.sort(m.emp, new Sortbyname());
       m.showEmployeeList();
       System.out.println("---------------");
       Collections.sort(m.emp, new Sortbysalary());
       m.showEmployeeList();
       System.out.println("---------------");
       Collections.sort(m.emp, new SortbyempId());
       m.showEmployeeList();
       System.out.println("---------------");
       



   }
}