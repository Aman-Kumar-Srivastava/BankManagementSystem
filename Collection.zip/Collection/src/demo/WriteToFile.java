package demo;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile {
	public static void main(String [] args) {
		try {
			FileWriter writer = new FileWriter("MyFile.txt");
			writer.write("Welcome to hcl");
			writer.close();
			System.out.println("Successfully Writen");
		}
		catch(IOException e) {
			System.out.println("An error occured");
			e.printStackTrace();
		}
	}

}
