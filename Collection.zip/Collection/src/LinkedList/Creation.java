package LinkedList;

import java.util.*;
public class Creation {

public static void main(String args[]) {
	List<Integer> ll=new LinkedList<>();
	ll.add(1);
	ll.add(2);
	ll.add(3);
	ll.add(4);
	ll.add(5);
	System.out.println(ll);
	Vector v=new Vector();
	v.addAll(ll);
	System.out.println(v);
	Stack s=new Stack();
	s.addAll(v);

	s.push(8);
	System.out.println(s);
	System.out.println(s.peek());
	System.out.println(s);
	System.out.println(s.pop());
	System.out.println(s);
	
}
}
