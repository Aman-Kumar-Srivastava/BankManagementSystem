package TreeMap;
import java.util.*;
public class creation {
	 public static void main(String args[]){  
		   TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		   map.put(103,"ramesh");  
		      map.put(100,"Aman");    
		      map.put(102,"ansh");    
		      map.put(101,"raghav");    
		      System.out.println(map);
		      
		      System.out.println("descendingMap: "+map.descendingMap());  
		     
		      System.out.println("headMap: "+map.headMap(102,true));  
		       
		      System.out.println("tailMap: "+map.tailMap(102,true));  
		      
		      System.out.println("subMap: "+map.subMap(101, true, 102, true));   
		 }  
		  

}
