package LinkedHashMap;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class creation {
	public static void main(String args[]){  
		   
		  LinkedHashMap<Integer,String> hm=new LinkedHashMap<Integer,String>();  
		  
		  hm.put(55,"Aman");  
		  hm.put(56,"Ismail");  
		  hm.put(57,"Saad");  
		  
		  System.out.println(hm);
		for(Entry<Integer, String> m:hm.entrySet()){  
		   System.out.println(m.getKey()+" "+m.getValue());  
		  } 
		
		  System.out.println("Keys: "+hm.keySet());  
	      
	       System.out.println("Values: "+hm.values());  
	       
	       hm.remove(55);  
	       System.out.println(hm);  
		 }  
	

}
