package LinkedHashMap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class sorting {
	public static void main(String args[]){  
	LinkedHashMap<String, Integer> map= new LinkedHashMap<>();
	map.put("raman0",73);
	map.put("raman1",67);
	map.put("raman2",25);
	map.put("raman3",89);
	map.put("raman4",93);
System.out.println(map);
for (Map.Entry<String, Integer> l : map.entrySet()) {
    System.out.println( l.getKey()
                       + "  "
                       + l.getValue());
}
List<Map.Entry<String, Integer> > list
    = new ArrayList<Map.Entry<String, Integer> >(
        map.entrySet());

Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() {
       
        public int compare(
            Map.Entry<String, Integer> entry1,
            Map.Entry<String, Integer> entry2)
        {

            
            return entry1.getValue()
                - entry2.getValue();
        }
    });

for (Map.Entry<String, Integer> l : list) {
    System.out.println( l.getKey()
                       + "  "
                       + l.getValue());
}
}
}
