package HashSet;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;
import java.util.TreeSet;

public class hetroDatatypes {
    
		public static void main(String[] args) {        
			Set set = new java.util.HashSet();     
			ArrayList al=new ArrayList();
			al.add("jahbshhss");
			al.add(663);
			System.out.println(al);
			Hashtable ash=new Hashtable();
			ash.put("ghfds", 889);
			ash.put(98, "hjsgdh");
			ash.put(789, al);
			ash.put(67, "hsgghv");
			System.out.println(ash);
			set.add("X");              
			set.add("Y");               
			set.add("Z");              
			set.add("A");               
			set.add(2); 
			set.add(2.09); 
			set.add('j'); 
			set.add(.982); 
			
			System.out.println("set : " + set);
		TreeSet tree=new TreeSet();
		tree.add("hj");
		//tree.add(-65776);
		System.out.println(tree);
		
		
		}
		
		
		

}
