package HashSet;

import java.util.HashSet;
import java.util.Iterator;

public class creationAndItreation {

	public static void main(String args[]){
	      HashSet<String> set = new HashSet<String>();
	      set.add("45");
	      set.add("19");
	      set.add("27");
	      set.add("89");
	      set.add("57");
	      set.add("19.09");
	      System.out.println(set);
	     
	   }

}
