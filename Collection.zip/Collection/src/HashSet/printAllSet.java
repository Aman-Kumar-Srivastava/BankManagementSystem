package HashSet;

import java.util.*;

public class printAllSet {

	public static void main(String args[]){
	      HashSet<String> set = new HashSet<String>();
	      TreeSet<String> set1 = new TreeSet<String>();
	      LinkedHashSet<String> set2 = new LinkedHashSet<String>();
	      for(int i=20; i>0; i--) {
	    	  set.add("A"+i);
	    	  set1.add("A"+i);
	    	  set2.add("A"+i);
	      }

	      System.out.println("hashset: " +set);
	      System.out.println("treeset: " +set1);
	      System.out.println("linkedhashset: " +set2);
	     
	   }

}
