package HashSet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;



public class sorting {
	
	
	 public static void main(String[] args)
	    {
	     
	       HashSet<Integer> c = new HashSet<>();
	        c.add(2018);
	        c.add(2020);
	        c.add(2013);
	        c.add(2015);
	        c.add(2017);
	 
	        System.out.println(c);
	        
	        
	        //sorting using treeset
	        TreeSet<Integer> treeSet = new TreeSet<>(c);
	        System.out.println(treeSet);
	   

}
}
