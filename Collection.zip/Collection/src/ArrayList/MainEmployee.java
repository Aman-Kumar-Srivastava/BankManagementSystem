package ArrayList;

import java.util.*;

public class MainEmployee {

		List<Employee1> emp=new ArrayList<>();

		     public void addEmployee(Employee1 employee) {
		         emp.add(employee);
		     }

		     public void removeEmployeebyId(int id) {
		            for(Employee1 e:emp) {
		                if(e.getEmpId()==id) {
		                    emp.remove(e);
		                }
		            }
		            showEmployeeList();
		        }

		     public void removeEmployeebyName(String name) {
		            for(Employee1 e:emp) {
		                if(e.getName()==name) {
		                    emp.remove(e);
		                }
		            }
		            showEmployeeList();
		        }

		        public void showEmployeeList() {
		            for(Employee1 employee:emp) {
		                System.out.println(employee.getEmpId()+" "+employee.getName()+" "+ employee.getSalary());
		            }


		 

		    }

		        public void searchbyName(String name) {
		            for(Employee1 employee:emp) {
		                if(employee.getName().equals(name)) {
		                    System.out.println(employee.getEmpId()+" "+ employee.getSalary());
		                }
		            }
		        }
		        public void searchbyId(int id) {
		            for(Employee1 employee:emp) {
		                if(employee.getEmpId()==id) {
		                    System.out.println(employee.getName());
		                }
		            }
		        }

		 

		    



		 

		    public static void main(String[] args) {
		        MainEmployee m=new MainEmployee();

		        Employee1 employee1=new Employee1(101,"saad",28820);
		        Employee1 employee2=new Employee1(102,"aman",28820);
		        Employee1 employee3=new Employee1(103,"ansh",28820);
		        Employee1 employee4=new Employee1(104,"ismail",28820);

		        m.addEmployee(employee1);
		        m.addEmployee(employee2);
		        m.addEmployee(employee3);
		        m.addEmployee(employee4);


		        m.showEmployeeList();
		        System.out.println("---------------");

		        m.removeEmployeebyId(103);
		        System.out.println("---------------");





		        m.searchbyName("saad");
		        System.out.println("---------------");
		        m.searchbyId(104);

		 

		    }

}
