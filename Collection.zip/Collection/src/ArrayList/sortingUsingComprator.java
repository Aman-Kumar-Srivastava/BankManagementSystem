package ArrayList;
import java.util.*;

class Car1 {
    int ModalNo;
    String name;
    int stock;
 

    Car1(int ModalNo, String name, int stock)
    {
        this.ModalNo = ModalNo;
        this.name = name;
        this.stock = stock;
    }
}
class StockComparator implements Comparator<Car1> {
    public int compare(Car1 c1, Car1 c2)
    {
        if (c1.stock == c2.stock)
            return 0;
        else if (c1.stock > c2.stock)
            return 1;
        else
            return -1;
    }
}
public class sortingUsingComprator {


	    public static void main(String[] args)
	    {
	    	
	        ArrayList<Car1> c = new ArrayList<Car1>();
	        c.add(new Car1(2018, "Kia", 20));
	        c.add(new Car1(2020, "MG", 13));
	        c.add(new Car1(2013, "creta", 10));
	        c.add(new Car1(2015, "BMW", 50));
	        c.add(new Car1(2017, "Audi", 45));
	 
	       
	        Collections.sort(c, new StockComparator());
	 
	      
	        for (Car1 car : c) {
	           
	   
	            System.out.println(car.stock + " " + car.name
	                               + " " + car.ModalNo);
	        }
	    }
	

}
