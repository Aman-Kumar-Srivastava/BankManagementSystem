package ArrayList;

import java.util.*;
class Car implements Comparable<Car> {
   private int ModalNo;
    private String name;
 

    Car(int ModalNo, String name)
    {
        this.ModalNo = ModalNo;
        this.name = name;
       
    }
 

    public int compareTo(Car car)
    {
        if (ModalNo == car.ModalNo)
            return 0;
        else if (ModalNo > car.ModalNo)
            return 1;
        else
            return -1;
    }
    
//    public String compare(Car car) {
//    	if(ModalNo==2018)
//    		return "Kia";
//    }
}
public class sortingUsingComprableInterface {

	    public static void main(String[] args)
	    {
	    	sortingUsingComprableInterface  e=new sortingUsingComprableInterface();
	        ArrayList<Car> c = new ArrayList<Car>();
	        c.add(new Car(2018, "Kia"));
	        c.add(new Car(2020, "MG"));
	        c.add(new Car(2013, "creta"));
	        c.add(new Car(2015, "BMW"));
	        c.add(new Car(2017, "Audi"));
	 

	        Collections.sort(c);

	        for (Car car : c) {
	 
	            System.out.println(car.ModalNo + " " + car.name);
	        }
	       // e.compare(2018);
	    }
}
