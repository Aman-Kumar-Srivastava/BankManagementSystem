package ArrayList;

import java.util.*;
class Emp {
    String field;
    String name;
 

    Emp(String name, String field)
    {
        this.field = field;
        this.name = name;
       
    }
}
public class employee {

	    public static void main(String[] args)
	    {
	    	//employee e=new employee();
	        ArrayList<Emp> c = new ArrayList<Emp>();
	        c.add(new Emp("aman", "backend"));
	        c.add(new Emp("saad", "frontend"));
	        c.add(new Emp("ansh", "testing"));
	        //System.out.println(c);

	        for (Emp emp : c) {
	            if(emp.field.equals("frontend"))
	            System.out.println(emp.name);
	        }
	       
	    }
	    
}