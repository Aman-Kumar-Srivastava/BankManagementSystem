package ArrayList;
import java.util.*;  
import java.io.*;  
public class sortListUsingMergeSort {  
//public static void main(String[] args)throws Exception{  
//  
//Properties p=System.getProperties();  
//Set set=p.entrySet();  
//  
//Iterator itr=set.iterator();  
//while(itr.hasNext()){  
//Map.Entry entry=(Map.Entry)itr.next();  
//System.out.println(entry.getKey()+" = "+entry.getValue());  
//}  
  
//}  
//}  
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class sortListUsingMergeSort {
//
	 static void merge(List<Integer> al, int l, int m, int r)
	    {

	        int n1 = m - l + 1;
	        int n2 = r - m;

	        
	       List<Integer> L= new ArrayList<>();
	       List<Integer> R= new ArrayList<>();
	        

	        for (int i = 0; i < n1; ++i)
	        L.set(i,al.get(l+i));
	        for (int j = 0; j < n2; ++j)
	        	R.set(j,al.get(m+1+j));
	        
	        
	        int i = 0, j = 0;
	        int k = l;
	        while (i < n1 && j < n2) {
	            if (L.get(i)<= R.get(j)) {
	                al.set(k, L.get(i));
	                i++;
	            }
	            else {
	            	 al.set(k, R.get(j));
	                j++;
	                
	            }
	            k++;
	        }
	 
	        /* Copy remaining elements of L[] if any */
	        while (i < n1) {
	        	 al.set(k, L.get(i));
	           
	            i++;
	            k++;
	        }
	 
	        /* Copy remaining elements of R[] if any */
	        while (j < n2) {
	        	 al.set(k, R.get(j));
	            j++;
	            k++;
	        }
	       
	    }
	 
	   
	   static void sort(List<Integer> al, int l, int r)
	    {
		 
		   
	        if (l < r) {
	           
	            int m = l + (r - l) / 2;
	 
	           
	            sort(al, l, m);
	            sort(al, m + 1, r);
	 
	            
	           merge(al, l, m, r);
	           
	            
	        }
	        
	    }
	 
	    
	    static void printArray(List<Integer> a)
	    {
	        int n = a.size();
	        for (int i = 0; i < n; ++i)
	            System.out.print(a.get(i) + " ");
	        System.out.println();
	    }
	 
	    
	    public static void main(String args[])
	    {
	        List<Integer> a=new ArrayList<>(); 
	        a.add(3);
	        a.add(4);
	        a.add(1);
//	        a.add(5);
//	        a.add(2);
	 
	        System.out.println("Given ArrayList");
	        printArray(a);
	 
	        
	       sort(a, 0, a.size() - 1);
	    
	        System.out.println("\nSorted arraylist");
	        printArray(a);
	        
	    }

}
