package ArrayList;

import java.util.ArrayList;
import java.util.List;

public class sorting {
	
	static void sortList(List<Integer> l){
		        int n = l.size();
		        for (int i = 0; i < n - 1; i++)
		            for (int j = 0; j < n - i - 1; j++)
		                if (l.get(j)> l.get(j+1)) {		                   
		                    int temp = l.get(j);
		                    l.set(j, l.get(j+1));
		                    l.set(j+1,temp);
		                   
		                }
		    
	}
public static void main(String args[]) {
	List<Integer> al=new ArrayList<>();
	al.add(10);
	al.add(3);
	al.add(2);
	al.add(11);
	al.add(9);
	System.out.println(al);
	sortList(al);
	System.out.println("After Sorting: ");
	System.out.println(al);
}

}
