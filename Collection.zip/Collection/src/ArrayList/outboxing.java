package ArrayList;

import java.util.ArrayList;
class intWrapper{
	public int intValue;

	public intWrapper(int intValue) {
		super();
		this.intValue = intValue;
	}

	public int getIntValue() {
		return intValue;
	}

	public void setIntValue(int intValue) {
		this.intValue = intValue;
	}
	 
}
public class outboxing {
 
public static void main(String args[]) {
	ArrayList<intWrapper> rollno =new ArrayList<>();
	rollno.add(new  intWrapper(10));
	rollno.add(new  intWrapper(11));
	rollno.add(new  intWrapper(12));
	rollno.add(new  intWrapper(13));
	for(int i=0; i<rollno.size(); i++) {
	System.out.println(rollno.get(i).getIntValue());
}
}
}
