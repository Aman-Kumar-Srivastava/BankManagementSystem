package ArrayList;

import java.util.*;
public class addMethod {
	Add first;
	 static class Add{
		 int data;
		 Add next;
		 Add(int d){
			 data=d;
			 next=null;
		 }
	 }
	 public void printdata() {
		 Add n=first;
			while(n!=null) {
				System.out.print(n.data+" ");
				n=n.next;
			}
			
		}
	 public static void main(String []args) {
			addMethod al= new addMethod();
			
			al.first=new Add(7);
			Add second= new Add(9);
			Add third=new Add(4);
			Add fourth=new Add(2);
			
			al.first.next=second;
			second.next=third;
			third.next=fourth;
			al.printdata();
		}

}
