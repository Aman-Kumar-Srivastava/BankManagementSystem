/**
 * COPYRIGHT
 */

package ArrayList;
import java.util.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * THis class if to make test Arraylist program
 * @author amankumar-srivastava
 *
 */
public class printing {
	static List<String> al = new ArrayList<>();
	List<String> list = new LinkedList<>();
	
	
	
	public static void main(String args[]) {

		al.add("aman");
		al.add("ansh");
		al.add("saad");
		al.add("ismail");
		al.add("sagar");
		//al.add(1);

		System.out.println(al);
		Set<String> tree=new TreeSet<>(al);
		System.out.println(tree);
		printing p = new printing();
		p.print(al);
		al.set(3, "dk");
		p.print(al);
		al.remove(0);
		System.out.println(al);
	}

	/**
	 * This method is to print elements of array list.
	 * @param al2
	 */
	void print(List<String> al2) {
		for (String s : al2) {
			System.out.println(s);
		}

	}
}