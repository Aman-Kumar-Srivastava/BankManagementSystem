package LinkedHashSet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
public class sorting {
	public static void main(String args[]) {
	 LinkedHashSet<Integer> set=new LinkedHashSet<Integer>();  
     set.add(7);    
     set.add(9);    
     set.add(4);   
     set.add(1);  
     set.add(8);  
     System.out.print(set);
     System.out.println();
     ArrayList<Integer> al = new ArrayList<>(set);
     Collections.sort(al);
     set=new LinkedHashSet<Integer>(al); 
     System.out.print(set);
     
     
   
  }
}
