package LinkedHashSet;

import java.util.Iterator;
import java.util.LinkedHashSet;


public class printing {

	 public static void main(String args[]){  
		 
		        LinkedHashSet<String> set=new LinkedHashSet<String>();  
		               set.add("aman");    
		               set.add("ansh");    
		               set.add("ismail");   
		               set.add("sagar");  
		               set.add("sandy");  
		               System.out.print(set);
		               System.out.println();
		               Iterator<String> i=set.iterator();  
		               while(i.hasNext())  
		               {  
		               System.out.print(i.next()+" ");  
		               }  
		 }  

}
