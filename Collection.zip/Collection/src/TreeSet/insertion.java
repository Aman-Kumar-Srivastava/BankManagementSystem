package TreeSet;

import java.util.TreeSet;
import java.util.Iterator;


public class insertion {
//insertion and iteration
	    public static void main(String[] args) {
	        TreeSet<Integer> num = new TreeSet<>();
	        //num.add(2);
	        num.add(5);
	        num.add(6);
	        num.add(2);
	        System.out.println("TreeSet: " + num);

	        // Calling iterator() method
	        Iterator<Integer> iterate = num.iterator();

	        while(iterate.hasNext()) {
	            System.out.println(iterate.next());
	           
	        }
	    }
	

}
