package TreeSet;


import java.util.TreeSet;
import java.util.Iterator;

public class sorting {

	public static void main(String args[]){
	      TreeSet<String> set = new TreeSet<String>();
	      set.add("65");
	      set.add("45");
	      set.add("19");
	      set.add("27");
	      set.add("89");
	      set.add("57");
	      System.out.println("Sorted");
	      Iterator<String> i = set.iterator();
	      while(i.hasNext()) {
	         System.out.print(i.next()+" ");
	      }
	      System.out.println("");
	      System.out.println("Descending order");
	      Iterator<String> j = set.descendingIterator();
	      while(j.hasNext()) {
	         System.out.print(j.next()+" ");
	      }
	   }
	}
	