package first;
import java.io.*;

public class Emp implements Serializable {
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	public Emp(String name, String last) {
		super();
		this.name = name;
		this.last = last;
	}
	String name;
	String last;
	}


