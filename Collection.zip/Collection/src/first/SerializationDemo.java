package first;
import java.io.*;

public class SerializationDemo  {
	public static void main(String[] args) {
		Emp e1=new Emp("Ankit","Rai");
		Emp e2=new Emp("Sarbajeet","Singh");
		Emp e3=new Emp("Aniket","Singh");
	try {
		FileOutputStream fo=new FileOutputStream("C:FileOperationExample.txt");
		ObjectOutputStream o=new ObjectOutputStream(fo);
		o.writeObject(e1);
		o.writeObject(e2);
		o.writeObject(e3);
		o.close();
		fo.close();
		System.out.println("Process Done");
		
	}
	catch(Exception e) {
		System.out.println("Error!!");
		e.printStackTrace();
	}
	

	}
}
