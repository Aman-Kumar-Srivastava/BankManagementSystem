package first;

import java.io.*;

public class Dd {

	public static void main(String[] args) throws IOException  {
		Emp emp=null;
		FileInputStream fi=null;
		ObjectInputStream in=null;
		try {
			fi=new FileInputStream("C:FileOperationExample.txt");
			 in=new ObjectInputStream(fi);
		while(true) {
			try{emp=(Emp)in.readObject();
			System.out.println("First Name: "+emp.name);
			System.out.println("Last Name: "+emp.last);
			}
			catch(EOFException e) {
				
			}
		}
//		in.close();
//		fi.close();
			
		}

          catch(Exception e) {
			System.out.println(e);
          		}
		finally {
			if (in!=null) {
		        in.close();
		    }
			if (fi!=null) {
		        fi.close();
		    }
		}
		

	}

}
