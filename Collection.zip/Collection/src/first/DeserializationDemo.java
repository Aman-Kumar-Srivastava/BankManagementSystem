package first;

import java.io.*;

public class DeserializationDemo {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Emp emp=null;
		Emp emp1=null;
		try {
			FileInputStream fi=new FileInputStream("C:FileOperationExample.txt");
			ObjectInputStream in=new ObjectInputStream(fi);
		
			emp=(Emp)in.readObject();	
			emp1=(Emp)in.readObject();
			 emp1=(Emp) in.readObject();
			in.close();
			fi.close();
			
		}
		finally {
			System.out.println("First Name: "+emp.name);
			System.out.println("Last Name: "+emp.last);
			System.out.println("First Name: "+emp1.name);
			System.out.println("Last Name: "+emp1.last);
			
		
		}

	}

}
