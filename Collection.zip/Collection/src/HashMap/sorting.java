package HashMap;

import java.util.*;

public class sorting {
	public static void main(String args[]) {
  HashMap<Integer,String> map=new HashMap<Integer,String>();    
	      map.put(103,"ramesh"); 
	      map.put(11,"rahul"); 
	      map.put(12,"ansh"); 
	      map.put(1007,"Aman");    
	      map.put(10,"Akash"); 
	            
	      System.out.println(map);
	      TreeMap<Integer,String> map1=new TreeMap<Integer,String>(map); 
	      
	      System.out.println(map1);

}
}
