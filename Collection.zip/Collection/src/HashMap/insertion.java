package HashMap;

import java.util.HashMap;
import java.util.Map;

public class insertion {

	 public static void main(String args[]){  
		   HashMap<Integer,String> map=new HashMap<Integer,String>();//Creating HashMap    
		   map.put(1,"hyy");  
		   map.put(2,"hello");    
		   map.put(3,"hcl");   
		   map.put(4,"odc5A");   
		   System.out.println(map);//direct method  
		   insert(map,5,"thanks");
		   insert(map,6,"welcome");
		   System.out.println(map);
		   insertAtLast(map,"in the last");
		   System.out.println(map);
		   
	 }
static void insert( HashMap<Integer,String> map, int x, String y) {
	map.put(x, y);  
		}

static void insertAtLast( HashMap<Integer,String> map, String y) {
	int n=map.size();
	map.put(n+1, y);
}
}
