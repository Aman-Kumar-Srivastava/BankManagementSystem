package HashMap;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
public class HashMapDemo {
	public static void main(String[] args) {
        Employee e1 = new Employee(1,"Ankit");
        Employee e2 = new Employee(5,"Sarabjeet");
        Employee e3 = new Employee(3,"Aniket");
        Employee e4 = new Employee(34,"Ansh");
        Employee e5 = new Employee(12,"Sriparno");
        Employee e6 = new Employee(398,"Vaidant");
        Employee e7=new Employee(234,"Vaidant");
        
        Map<Employee,Integer> map = new HashMap<>();
        map.put(e1, 1);
        map.put(e2, 2);
        map.put(e3, 4);
        map.put(e4, 5);
        map.put(e5, 7);
        map.put(e6, 9);
        map.put(e7, 2);
        System.out.println("--------UnSorted-------------)");
        map.entrySet()
        .stream()
        .forEach(System.out::println);
        System.out.println("--------Sorted On The Basis Of Key(i.e Id Of Employee Class)----------------");
        map.entrySet()
        .stream()
        .sorted(Map.Entry.comparingByKey())
        .forEach(System.out::println);
        System.out.println("--------Sorted On The Basis Of Value In Reverse Order----------------");
        map.entrySet()
        .stream()
        .sorted(Map.Entry.comparingByValue((Comparator.reverseOrder())))
        .forEach(System.out::println);
        Map<String,Integer> map2=new HashMap<>();
        map2.put(e1.getName(), e1.getName().length());
        map2.put(e2.getName(), e2.getName().length());
        map2.put(e3.getName(), e3.getName().length());
        map2.put(e4.getName(), e4.getName().length());
        map2.put(e5.getName(), e5.getName().length());
        map2.entrySet()
        .stream()
        .forEach(System.out::println);
        List<Employee> al=new ArrayList<>();
        al.add(e1);
        al.add(e2);
        al.add(e3);
        al.add(e4);
        al.add(e5);
        al.add(e6);
        al.add(e7);

       List<String>dn= al.stream().map(Employee::getName)
        .collect(Collectors.toList()).stream()
        .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
        .entrySet().stream().filter(e->e.getValue()>1)
        .map(Map.Entry::getKey)
        .collect(Collectors.toList());
       System.out.println("Duplicate Name In Employee Class Is:"+dn);
     


        
        

        
        
}
        
}

