package HashMap;
import java.util.*;
import java.util.Map.Entry;
public class iteration {
	 public static void main(String args[]){  
		   HashMap<Integer,String> map=new HashMap<Integer,String>();//Creating HashMap    
		   map.put(1,"hyy");  
		   map.put(2,"hello");    
		   map.put(3,"hcl");   
		   map.put(4,"odc5A");   
		   System.out.println(map);//direct method  
		   print(map);
		   map.entrySet()
	        .stream().sorted(Map.Entry.comparingByKey())
	        .forEach(System.out::println);
		   
	 }
		   //iterartion method
		   static void print(HashMap<Integer,String> map) {
		   for(int m : map.keySet()){    
		    System.out.println(m+" "+map.get(m));    
		   }  
		   
		   for(int m = 1 ; m<=map.size(); m++){    
			    System.out.print(map.get(m)+" "+m+" ");    
			   }  
		   
		}
		   

}
