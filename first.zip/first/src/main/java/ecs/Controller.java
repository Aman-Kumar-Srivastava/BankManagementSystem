package ecs;

import jakarta.annotation.Resource;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.sql.DataSource;

@WebServlet("/first/Controller")
public class Controller extends HttpServlet {
	public static int counter = 1;
	public static int price=1000;
    private static final long serialVersionUID = 1L;
    @Resource(name="jdbc/project")
    private DataSource datasource;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	PrintWriter out=response.getWriter();
      Connection c=null;
      Statement st=null;
      ResultSet rs=null;
      try {
          c=datasource.getConnection();
              String query="select *from img3 where product_id=1001";
              st=c.createStatement();
              rs=st.executeQuery(query);
              
              while(rs.next()) {
                  //out.println("<br/>"+ rs.getString("name")+"   "+rs.getString("phone")+"   "+rs.getString("flat")+"   "+rs.getString("apt"));
             price=Integer.parseInt(rs.getString(11));
              }
      }catch (SQLException e) {	
        e.printStackTrace();
    }
            Counter counter;
            //Counter price;
	        counter = (Counter) request.getAttribute("counter");
	        //price=(Counter) request.getAttribute("product1");
	        if (counter == null)
	        {
	           
	           counter =new Counter();
	        }
//	        if(price==null)
//	        {
//	            
//	            price =new Counter();
//	        }
	        //String price = request.getParameter("ammount");
	        String increment = request.getParameter("increment");
	        if (increment != null)
	        {
	            counter.increment();
	           // price.increment();
	            
	        }

	        String reset = request.getParameter("decrement");
	        if (reset != null)
	        {
	            counter.decrement();
	            //price.increment();
	        }
    
	        request.setAttribute("counter", counter.getCounter());
	        request.setAttribute("price", counter.getPrice());
	        request.getRequestDispatcher("/cart.jsp").forward(request, response);
    }

	public class Counter {

	    

	    public void increment() {
	        counter++;
	        //price=price*counter;
	    }

	    public void decrement() {
	    	if(counter>1)
	        counter--;
	        //price=price*counter;
	    }

	    public void reset() {
	        counter = 0;
	        //price=0;
	    }

	    public int getCounter() {

	        return counter;
	    }
	    public int getPrice() {

	        return price*counter;
	    }
	    
	}
	//}
//	PrintWriter out=response.getWriter();
//    Connection c=null;
//    Statement st=null;
//    ResultSet rs=null;
//    try {
       // c=datasource.getConnection();
//            String query="select *from ordrcrfm";
//            st=c.createStatement();
//            rs=st.executeQuery(query);
//            
//            while(rs.next()) {
//                out.println("<br/>"+ rs.getString("name")+"   "+rs.getString("phone")+"   "+rs.getString("flat")+"   "+rs.getString("apt"));
//           
//            }
//                String query1="select *from loginUser";
//                st=c.createStatement();
//                rs=st.executeQuery(query1);
//                out.println("<br/>"+"Name  "+" Contact No  "+" E-mail "+" Password "+" Place");
//                while(rs.next()) {
//                out.println("<br/>"  +rs.getString("name")+" "+rs.getString("phone")+" "+rs.getString("email")+" "+ 
//                rs.getString("password")+" "+rs.getString("place"));
//                }
//        } catch (SQLException e) {	
//            e.printStackTrace();
//        }
    //}
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        	PrintWriter out=response.getWriter();
            Connection c=null;
            Statement st=null;
            ResultSet rs=null;
            HttpServletRequest request1;
            try {
                c=datasource.getConnection();
                String name=request.getParameter("name");
                String contact=request.getParameter("contact");
                String email=request.getParameter("email");
                String psw=request.getParameter("psw");
                String qremember=request.getParameter("qremember");
                PreparedStatement ps=c.prepareStatement( "INSERT INTO loginUser" +
                        "  (name ,phone,email,password,place) VALUES " +
                        " (?,?,?,?,?);");
                ps.setString(1,name);
                ps.setString(2,contact);
                ps.setString(3,email);
                ps.setString(4,psw);
                ps.setString(5,qremember);
                st=c.createStatement();
            	int x=ps.executeUpdate();
            	if(x>0){
            		out.println("data inserted");
            	}else{
            		out.println("error");
            	}
            }
            catch(SQLException e) {
            	e.printStackTrace();
            }
        }
       
}