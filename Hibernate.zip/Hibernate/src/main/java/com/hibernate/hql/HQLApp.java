package com.hibernate.hql;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.Query;


public class HQLApp {
	public static void main(String args[]) {
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory factory = cfg.buildSessionFactory();
	
	
	

	
	
	Session s= factory.openSession();
	Transaction tx = s.beginTransaction();
	
	String query="from Student as s where s.name=:x";
	Query q= s.createQuery(query);
	q.setParameter("x","aman");
	List<Student> students=q.getResultList();
	
	for(Student s1: students) {
	System.out.println(s1.getName());
	}
//	String query1="delete from Student as s where s.name=:c";
//	Query q2= s.createQuery(query1);
//	q2.setParameter("c","ankit");
//	int r=q2.executeUpdate();
//	System.out.println("Deleted:: "+r);
	String query2="update Student set name=:v  where name=:x";
	Query q3= s.createQuery(query2);
	q3.setParameter("v","aks");
	q3.setParameter("x","aman");
	
	int r=q3.executeUpdate();
	System.out.println("Upadted:: "+r);
	tx.commit();
	s.close();
	factory.close();
}
}
