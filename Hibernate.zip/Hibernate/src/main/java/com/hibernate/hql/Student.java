package com.hibernate.hql;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Student_HQL")
public class Student {
	@Id
    private int id;
    private String name;
    @OneToMany(mappedBy="Student")
    private List<Project> projects;
    
	public List<Project> getProjects() {
		return projects;
	}
	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Student(int id, String name, List<Project> projects) {
		super();
		this.id = id;
		this.name = name;
		this.projects = projects;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", projects=" + projects + "]";
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	
	
}
