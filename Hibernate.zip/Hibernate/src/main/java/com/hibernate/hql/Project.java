package com.hibernate.hql;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="HQLProject")
public class Project {
   
	@Id
	private int id;
	private String projName;
	@ManyToOne
	private Student Student;
	@Override
	public String toString() {
		return "Project [id=" + id + ", projName=" + projName + ", Student=" + Student + "]";
	}
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProjName() {
		return projName;
	}
	public void setProjName(String projName) {
		this.projName = projName;
	}
	public Student getStudent() {
		return Student;
	}
	public void setStudent(Student student) {
		Student = student;
	}
	public Project(int id, String projName, Student student) {
		super();
		this.id = id;
		this.projName = projName;
		Student = student;
	}
	
}
