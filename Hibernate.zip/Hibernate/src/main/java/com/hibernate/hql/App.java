package com.hibernate.hql;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class App {
	public static void main(String args[]) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Student s1=new Student();
		Student s2=new Student();
		Student s3=new Student();
		s1.setId(100);
		s1.setName("aman");
		s2.setId(101);
		s2.setName("saad");
		s3.setId(102);
		s3.setName("ankit");
		Project p1=new Project();
		Project p2=new Project();
		Project p3=new Project();
		p1.setId(23);
		p1.setProjName("E-com");
		p2.setId(25);
		p2.setProjName("EMS");
		p3.setId(27);
		p3.setProjName("LMS");
		
		
		List<Project> project=new ArrayList();
		List<Project> project1=new ArrayList();
		
		project.add(p1);
		project.add(p2);
		project.add(p3);
		project1.add(p1);
		project1.add(p2);
		s1.setProjects(project);
		s3.setProjects(project1);
		p1.setStudent(s1);
		p2.setStudent(s1);
		p3.setStudent(s1);
	
		
		
		Session s= factory.openSession();
		Transaction tx = s.beginTransaction();
		
		s.persist(s1);
		s.persist(s2);
		s.persist(s3);
		s.persist(p1);
		s.persist(p2);
		s.persist(p3);
		
		
		
		tx.commit();
		
		factory.close();
	}
}
