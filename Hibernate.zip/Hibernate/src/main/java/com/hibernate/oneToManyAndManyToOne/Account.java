package com.hibernate.oneToManyAndManyToOne;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Account {
  @Id  
  private int id;
  private String bankName;
  @ManyToOne
  private Employee employee;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}
public Employee getEmployee() {
	return employee;
}
public void setEmployee(Employee employee) {
	this.employee = employee;
}
@Override
public String toString() {
	return "Account [id=" + id + ", bankName=" + bankName + ", employee=" + employee + "]";
}
public Account(int id, String bankName, Employee employee) {
	super();
	this.id = id;
	this.bankName = bankName;
	this.employee = employee;
}
public Account() {
	super();
	// TODO Auto-generated constructor stub
}
  
}
