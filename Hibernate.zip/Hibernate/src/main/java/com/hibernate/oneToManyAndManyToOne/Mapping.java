package com.hibernate.oneToManyAndManyToOne;

import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Mapping {
	public static void main(String args[]) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Employee emp=new Employee();
		emp.setEmpId(90);
		emp.setEmpName("Aman");
		Account a1=new Account();
		Account a2=new Account();
		Account a3=new Account();
		a1.setId(101);
		a1.setBankName("icici");
		a2.setId(109);
		a2.setBankName("hdfc");
		a3.setId(1011);
		a3.setBankName("union");
		a1.setEmployee(emp);
		a2.setEmployee(emp);
		a3.setEmployee(emp);
		
		List<Account> account=new ArrayList<Account>();
		account.add(a1);
		account.add(a2);
		account.add(a3);
		emp.setAccount(account);
		
		
//		System.out.println(emp.toString());
//		System.out.println(a1.toString());
//		System.out.println(a2.toString());
//		System.out.println(a3.toString());
		Session s= factory.openSession();
		Transaction tx = s.beginTransaction();
		
		s.save(emp);
		s.save(a1);
		s.save(a2);
		s.save(a3);
		tx.commit();
		
		factory.close();
	}
}
