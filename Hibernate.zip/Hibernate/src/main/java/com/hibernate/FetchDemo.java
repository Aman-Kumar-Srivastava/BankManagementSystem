package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FetchDemo {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		//get-Student:11
		
		Student student = session.load(Student.class,15 );
		System.out.println(student);
		
		//get-Address:1
		
		Address address = session.get(Address.class, 1);
		System.out.println(address.getStreet());
		
		session.close();
		factory.close();
	}
}
