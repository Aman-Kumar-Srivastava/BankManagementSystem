package com.hibernate.manyToMany;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class ManyMapping {
	public static void main(String args[]) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Student s1=new Student();
		Student s2=new Student();
		Student s3=new Student();
		s1.setStuId(100);
		s1.setStuName("aman");
		s2.setStuId(101);
		s2.setStuName("saad");
		s3.setStuId(102);
		s3.setStuName("ankit");
		Project p1=new Project();
		Project p2=new Project();
		Project p3=new Project();
		p1.setProjId(23);
		p1.setProjName("E-com");
		p2.setProjId(25);
		p2.setProjName("EMS");
		p3.setProjId(27);
		p3.setProjName("LMS");
		
		List<Student> student=new ArrayList();
		List<Project> project=new ArrayList();
		student.add(s1);
		student.add(s2);
		student.add(s3);
		project.add(p1);
		project.add(p2);
		project.add(p3);
		s1.setProject(project);
		p2.setStudent(student);
		
		
		Session s= factory.openSession();
		Transaction tx = s.beginTransaction();
		
		s.persist(s1);
		s.persist(s2);
		s.persist(s3);
		s.persist(p1);
		s.persist(p2);
		s.persist(p3);
		
		
		
		tx.commit();
		
		factory.close();
	}

}
