package com.hibernate.manyToMany;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Project {
	@Id
	private int projId;
	private String projName;
	@ManyToMany(mappedBy="project")
	private List<Student> student;
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Project(int projId, String projName, List<Student> student) {
		super();
		this.projId = projId;
		this.projName = projName;
		this.student = student;
	}
	@Override
	public String toString() {
		return "Project [projId=" + projId + ", projName=" + projName + ", student=" + student + "]";
	}
	
	public int getProjId() {
		return projId;
	}
	public void setProjId(int projId) {
		this.projId = projId;
	}
	public String getProjName() {
		return projName;
	}
	public void setProjName(String projName) {
		this.projName = projName;
	}
	public List<Student> getStudent() {
		return student;
	}
	public void setStudent(List<Student> student) {
		this.student = student;
	}
	
}
