package com.hibernate.manyToMany;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Student_ManyMapping")
public class Student {
	@Id
	private int stuId;
	private String stuName;
	
	@ManyToMany
	private List<Project> project;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(int stuId, String stuName, List<Project> project) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.project = project;
	}

	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", stuName=" + stuName + ", project=" + project + "]";
	}

	public int getStuId() {
		return stuId;
	}

	public void setStuId(int stuId) {
		this.stuId = stuId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public List<Project> getProject() {
		return project;
	}

	public void setProject(List<Project> project) {
		this.project = project;
	}

}
