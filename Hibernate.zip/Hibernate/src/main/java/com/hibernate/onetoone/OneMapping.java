package com.hibernate.onetoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OneMapping {
	public static void main(String args[]) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Answer ans=new Answer();
		ans.setAnswerId(1);
		ans.setAnswer("it is a programming language");
		Question q=new Question();
		q.setQuesID(0);
		q.setQuestion("what is java");
		q.setAnswer(ans);
		
		
		Session s= factory.openSession();
		Transaction tx = s.beginTransaction();
		
		s.persist(q);
		s.persist(ans);
		
		tx.commit();
		
		factory.close();
	}
}
