package com.shop2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.shop2.entity.Product;
import com.shop2.entity.TransactionTable;
import com.shop2.repository.ProductRepository;
import com.shop2.repository.Transactionrepository;


@Component
public class ProductService {

	@Autowired
	private ProductRepository repo;
	@Autowired
	private Transactionrepository tRepo;
	public List<Product> getAllProducts(){
		  List<Product> list=(List<Product>)this.repo.findAll();	  
		  return list;
	  }
	public Product save(Product p){
	return repo.save(p);
	} 
	
	public void update(Product p, String q){
		p.setQuantity(q);
		repo.save(p);
		}
	
	public List<TransactionTable> getAllTrans(){
		List<TransactionTable> tList=(List<TransactionTable>)this.tRepo.findAll();
		return tList;
	}
	public void transaction(TransactionTable trans) {
		tRepo.save(trans);
	}

}
