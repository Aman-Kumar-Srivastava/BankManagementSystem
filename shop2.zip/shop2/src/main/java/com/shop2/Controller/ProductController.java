package com.shop2.Controller;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.shop2.entity.Product;
import com.shop2.entity.TransactionTable;
import com.shop2.service.ProductService;
import org.springframework.stereotype.Controller;


@Controller
public class ProductController {
String w[]=new String[5];	
@Autowired
	private ProductService service; 
	@GetMapping("/home")
	public String viewHomePage(Model model) {
		List<Product> list = service.getAllProducts();
		
		model.addAttribute("list", list);
		System.out.print("Get / home page....");
		return "home";
		
}
	@PostMapping("/homepost")
	public Product saveProduct(@RequestBody Product p) {
	this.service.save(p);
	return p; 
	 }
	@PostMapping("/wallet")
	public String wallet( @RequestBody String q, Model mod) {
		System.out.println("hyy...."+q);
		String p[]=q.split("&");
		String s1[]=new String[3];
		for(String s :p) {
			String str[]=s.split("=");		
			if(str.length==2) {
				s1[0]=str[0];
				s1[1]=str[1];
				w[0]=s1[0];
				w[4]=s1[1];
				System.out.println(w[0]);
			break; 
			}
		}
		List<Product> list = service.getAllProducts();
		for(Product e: list) {
			if(e.getProd_id()==Integer.parseInt(s1[0])) {
				w[1]=e.getProd_name();
				w[2]=e.getBuy_price();
				w[3]=e.getSale_price();
			
			s1[2]=String.valueOf(Integer.parseInt(s1[1])*Integer.parseInt(e.getSale_price()));	
			
			}
		}
		
		System.out.println(s1[0]+" "+s1[1]+" "+s1[2]+".....");
		mod.addAttribute("s1",s1);
		
		return "Wallet";
	}
	@PostMapping("/transaction")
	public String trans(@ModelAttribute() String s,@RequestBody String p, Model m) {
		
		System.out.println(p+"..."+w[0]+";;"+w[2]);
		String str[]=p.split("&");
		String p1=str[0].substring(6);
		String p2=str[1].substring(5);
		String p3=str[2].substring(6);
		String p4=str[4].substring(7);
		String p5=str[6].substring(5);
				
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p4);
		System.out.println(p5);
		//System.out.println(p2);
		List<Product> list = service.getAllProducts();
		for(Product e: list) {
			if(e.getProd_name().equals(w[1])) {
				System.out.println(e.getProd_name()+"dvjkhfjdk");
				String q=Integer.toString(Integer.parseInt(e.getQuantity())-Integer.parseInt(w[4]));
			service.update(e, q);
			}
		}
//		TransactionTable t=new TransactionTable();
//		t.setTransId(12);
//		t.setProdId("5");
//		t.setProd_name("i");
//		t.setBuy_price("900"); 
//		t.setEmail("kl");
//		t.setSale_price("op");
//		t.setQuantitySold("0");
//		t.setDate("poi");
//		t.setFirstname("pok");
//		t.setLastname("jk");
				TransactionTable t1=new TransactionTable(1,w[0],w[1],w[2],w[3],w[4],p5,p1,p2,p3);
    	this.service.transaction(t1);
		return "redirect:/home";
	}
	@GetMapping("/ShowProfit")
	public String viewProfit(Model model) {
		
		return "ShowProfit";
	}
	@GetMapping("/stockUpdate")
	public String updateStock(Model model) { 
		
		return "stockUpdate";
	}
	
	@PostMapping("/profit")
	public String profit(@RequestBody String p, Model m) {
		System.out.println(p);
		String str[]=p.split("&");
		String p1=str[0].substring(6);
		String p2=str[1].substring(5);
		System.out.println(p1);
		//List<Product> list = service.getAllProducts();
		List<TransactionTable> list=service.getAllTrans();
		List<TransactionTable> l=new ArrayList<>();
		for(TransactionTable e: list) {
			if(e.getProd_name().equals(p1) && e.getDate().equals(p2)){
				System.out.println(e.getProd_name());
			l.add(e);	
			}
		}
		System.out.println(l.toString());
		m.addAttribute("l", l);
		return "profit";
	}
	@PostMapping("/update")
	public String update(@RequestBody String p, Model m) {
		System.out.println(p);
		String str[]=p.split("&");
		String p1=str[0].substring(6);
		String q=str[1].substring(9);
		System.out.println(p1);
		System.out.println(q);
		List<Product> list = service.getAllProducts();
		for(Product e: list) {
			if(e.getProd_name().equals(p1)) {
				System.out.println(e.getProd_name());
			service.update(e, q);
			}
		}
//		
		return "redirect:/home";
	}
}
