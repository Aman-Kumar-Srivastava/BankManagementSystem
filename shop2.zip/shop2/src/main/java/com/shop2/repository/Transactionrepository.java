package com.shop2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shop2.entity.TransactionTable;

public interface Transactionrepository extends JpaRepository<TransactionTable, Long> {

}
