package com.shop2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TransactionTable {
	
	
	 @Id
	 @GeneratedValue(strategy=GenerationType.AUTO)
	 private int transId;
	 private String prodId;
	 private String prod_name;
	 private String buy_price;
	 private String sale_price;
	 private String quantitySold;
	 private String date;
	 private String firstname;
	 private String lastname;
	 private String email;
	 public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public TransactionTable() {
			super();
			
		}

	
	
	public TransactionTable(int transId, String prodId, String prod_name, String buy_price, String sale_price, String quantitySold,
			String date, String firstname, String lastname, String email) {
		super();
		this.transId = transId;
		this.prodId=prodId;
		this.prod_name = prod_name;
		this.buy_price = buy_price;
		this.sale_price = sale_price;
		this.quantitySold = quantitySold;
		this.date = date;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public String getBuy_price() {
		return buy_price;
	}
	public void setBuy_price(String buy_price) {
		this.buy_price = buy_price;
	}
	public String getSale_price() {
		return sale_price;
	}
	public void setSale_price(String sale_price) {
		this.sale_price = sale_price;
	}
	public String getQuantitySold() {
		return quantitySold;
	}
	public void setQuantitySold(String quantitySold) {
		this.quantitySold = quantitySold;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getProdId() {
		return prodId;
	}
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}
	@Override
	public String toString() {
		return "TransactionTable [transId=" + transId + ", prodId=" + prodId + ", prod_name=" + prod_name
				+ ", buy_price=" + buy_price + ", sale_price=" + sale_price + ", quantitySold=" + quantitySold
				+ ", date=" + date + ", firstname=" + firstname + ", lastname=" + lastname + ", email=" + email + "]";
	}

	

}
