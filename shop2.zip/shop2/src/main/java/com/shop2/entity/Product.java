package com.shop2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Product {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 private int prod_id;
	 
	 
	 private String prod_name;
	 private String buy_price;
	 private String sale_price;
	 private String quantity;
	 public Product() {
			
		} 
	 public Product(int prod_id, String prod_name, String buy_price, String sale_price, String quantity) {
		super();
		this.prod_id = prod_id;
		this.prod_name = prod_name;
		this.buy_price = buy_price;
		this.sale_price = sale_price;
		this.quantity = quantity;
	}
	public int getProd_id() {
		return prod_id;
	}
	public void setProd_id(int prod_id) {
		this.prod_id = prod_id;
	}
	 public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public String getBuy_price() {
		return buy_price;
	}
	public void setBuy_price(String buy_price) {
		this.buy_price = buy_price;
	}
	public String getSale_price() {
		return sale_price;
	}
	public void setSale_price(String sale_price) {
		this.sale_price = sale_price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
   	
	
	 @Override
	public String toString() {
		return "Product [prod_id=" + prod_id + ", prod_name=" + prod_name + ", buy_price=" + buy_price + ", sale_price="
				+ sale_price + ", quantity=" + quantity + "]";
	}
	
	


}
