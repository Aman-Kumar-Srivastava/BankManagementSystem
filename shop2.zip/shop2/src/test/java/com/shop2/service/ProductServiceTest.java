package com.shop2.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.BDDMockito.Then;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mock.Strictness;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.shop2.entity.Product;
import com.shop2.repository.ProductRepository;


//@SpringBootTest
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = org.mockito.quality.Strictness.LENIENT)
public class ProductServiceTest {
	 
//	 @Autowired
//     private ProductService ser;
	
	  //@MockBean
	  @Mock
	  private ProductRepository repo;
	  
	  @InjectMocks
	  private ProductService ser;
	  
	  Product p;
	  
	  @BeforeEach
	  void setUp(){
		p=new Product(12,"PenDrive","1000","1400","50");
		p=new Product(12,"PenDrive1","100","1400","50");
		p=new Product(12,"PenDrive2","10","1400","50");
//		  Mockito.when(repo.isProductExitsByName("PenDrive")).thenReturn(p);
	  }
	  @Test
	  void saveProduct() {
		  when(repo.save(p)).thenReturn(p);
		  assertEquals(p, ser.save(p));
		  
	  } 
	  
	  @Test
	  void TestGetAllProduct() {
		  ser.getAllProducts();
		  verify(repo).findAll();

	  }

}
