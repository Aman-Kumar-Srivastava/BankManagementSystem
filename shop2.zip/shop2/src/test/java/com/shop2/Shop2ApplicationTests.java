package com.shop2;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.shop2.entity.Product;
import com.shop2.service.ProductService;

@SpringBootTest
class Shop2ApplicationTests {
	
	@Autowired
	private ProductService service;

    @BeforeEach  
    public void setUp() throws Exception {  
        System.out.println("before each");  
    }  
    
	@Test
	void contextLoads() {
	}
	
	@Test()
	void checkProduct() {
		String s="keyboard";
		List<Product> list=service.getAllProducts();
		int count=0;
		for(Product p: list) {
			if(p.getProd_name().equals(s)) {
				count++; break;
			}
			
		}
		assertEquals(1,count);
		
	}


}
