package com.shop2.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.shop2.entity.Product;

@SpringBootTest
public class ProductRepo {
  @Autowired
  private ProductRepository repo;
  
  @Test
  void findProduct() {
	 // String name="PenDrive";
	  Product p=new Product(12,"usb","1000","1400","50");
	  repo.save(p); 
	  Product res=repo.isProductExitsByName("usb");
	  assertEquals(p,res);
  }


}
