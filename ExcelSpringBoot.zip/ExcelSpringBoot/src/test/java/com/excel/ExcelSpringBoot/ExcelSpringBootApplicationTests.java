package com.excel.ExcelSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
