package com.excel.ExcelSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelSpringBootApplication.class, args);
	}

}
