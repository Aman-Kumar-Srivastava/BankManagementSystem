package com.excel.ExcelSpringBoot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.excel.ExcelSpringBoot.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{
	
}
