package com.excel.ExcelSpringBoot.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Product {
	
	@Id
	private Integer productId;
	@NotNull 
	private String productName;
	@NotNull	
	private String productDesc;
	@NotNull
	//@Pattern(regexp="^[0-9.]$")
	private Double productPrice;
	
}

