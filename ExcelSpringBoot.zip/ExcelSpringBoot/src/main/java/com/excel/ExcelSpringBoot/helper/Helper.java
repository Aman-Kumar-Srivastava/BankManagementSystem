package com.excel.ExcelSpringBoot.helper;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.excel.ExcelSpringBoot.entity.Product;

public class Helper {

	public static boolean checkExcelFormate(MultipartFile file) {
		String contentType = file.getContentType();
		if (contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
			return true;
		else
			return false;
	}

	public static List<Product> convetExcelToListOfProduct(InputStream is) {

		List<Product> list = new ArrayList<>();
        int c=0;
		try {
			XSSFWorkbook workbook = new XSSFWorkbook(is);
			XSSFSheet sheet = workbook.getSheet("data");
			int rowNumber = 0;
			Iterator<Row> iterator = sheet.iterator();

			while (iterator.hasNext()) {
				Row row = iterator.next();
				c++;
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}
				Iterator<Cell> cells = row.iterator();
				int cid = 0;
				Product p = new Product();
            
				while (cells.hasNext()) {
					Cell cell = cells.next();
					switch (cid) {
					case 0:
						if(!Integer.toString((int)cell.getNumericCellValue()).equals(null))
						p.setProductId((int) cell.getNumericCellValue());
						break;
					case 1:
						if(!cell.getStringCellValue().equals(null))
						p.setProductName(cell.getStringCellValue());
						break;
					case 2:
						if(!cell.getStringCellValue().equals(null))
						p.setProductDesc(cell.getStringCellValue());
						break;
					case 3:
						//if((double)cell.getNumericCellValue()!=(Double)null)
//						if(((double)cell.getNumericCellValue())!=(Double)null) {
							//if(Double.valueOf(cell.getNumericCellValue()) != null)
						//if(!Double.toString((double)cell.getNumericCellValue()).equals(null))
						p.setProductPrice((double)cell.getNumericCellValue());
						break;
						//}
					default:
						break;
					}
					cid++;
				}
				System.out.println(p.toString());
				list.add(p);
			}

		}
		catch (Exception e) {
			System.out.println("Row "+(c-1)+" has some values are null or maybe not proper calling from helper");
		} 
		return list;
	}
	

}

