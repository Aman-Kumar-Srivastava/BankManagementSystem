package array;


import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.Collectors;
public class Result{

	
	public static int getDiscountedPrice(int barcode) {
		String temp1="";
		String temp2="";
		String a="";
		try {
			String url="https://jsonmock.hackerrank.com/api/inventory?barcode="+barcode;
			URL url2=new URL(url);
			HttpURLConnection conn=(HttpURLConnection)url2.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();
			BufferedReader br= new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String result=br.readLine();
			if(result.length()<90)
				return -1;
				System.out.println("result");
				System.out.println(result.indexOf("page"));
			}
		catch(Exception e) {
			System.out.println(e);
		}
		return -1;
		
	}
	
	public static void main(String args[]) throws IOException{
		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));
		int barcode=Integer.parseInt(bufferedReader.readLine().trim());
		int result=getDiscountedPrice(barcode);
		bufferedWriter.write(String.valueOf(result));
		bufferedWriter.newLine();
		bufferedReader.close();
		bufferedWriter.close();
			
	}
}
