package array;

public class mergeSwap {
	 static int c=0;
	 static void countSwap(int arr[]) {
		for(int i=arr.length-1; i>0; i--) {
			for(int j=i-1; j>=0; j--) {
				if(arr[i]<arr[j]) {
					System.out.println(arr[i]+"   "+arr[j]);
					c++;
					break;
				}
			}
		}
		
		 
	 }
	 public static void main(String args[])
	    {
	        int arr[] = { 2, 3, 1};
	 
	       countSwap(arr);
	        System.out.println("final c : "+c);
	        System.out.println("5, 6, 8, 11, 12, 13");
	    }

}
