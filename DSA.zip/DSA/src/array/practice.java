package array;

import java.util.*;



public class practice {
  public double calD(double am){
	  return am*15/100;
	   
   }
  public Double calD(Double am){
	  return am*20/100;
	   
   }
	public static void main(String args[]) {
		practice p=new practice();
		double am=100.0;
		double d1=p.calD(am);
		
		Double a2=200.0;
		double d2=p.calD(a2);
		System.out.println(d1+":"+d2);
//		ArrayList al=new ArrayList<>();
//		Boolean b=true;
//		al.add(1);
//		al.add(2);
//		al.add(3);
//		b=al.contains(4);
//		if(b) {
//			System.out.println("hyy");
//		}
//		else
//			System.out.println("bye");
//		int arr[]= {1,2,3};
//		int[] arr2=new int[2];
//		arr2[0]=10;
		//System.out.println(arr.length+":"+arr2.length);
//		String  name="Angel";
//		int s=70;
//		System.out.printf("Miss. %s's score is %d ",name,s);
//		short x=1;
//		String y="2";
//		int a=100;
//		 switch(a) 
//		 {
//		 case 10:
//			 System.out.println("ten");
//		 case 100:
//			 System.out.println("h");
//		 case 1000:
//		    System.out.println("t");
//		    default:
//		   System.out.println("unit"); 	
//		 }
			
			
//		short s=(y+x);
		
		/*and comment
		 * hyy
		 */
		
//		int x=10;
//		int y=10;
//		x=x--;
//		y=--y;
//		if(x<y) {
//			x--;
//			y--;
//		}
//		else {
//			x++;
//			y++;
//		}
//		System.out.println("x= "+x+" y= "+y);
//		Scanner sc= new Scanner(System.in);//to read values from console
//		int n=-sc.nextInt();
//		int n=4, k=2;
//		String s="01011";
//		int i=0;
//		while(i<n-k+1) {
//			if(s.charAt(i)=='1') {
//				for(int m=i; m<k+i; m++) {
//				if(s.charAt(m)=='0')
//					s= s.substring(0, m) + '1'
//		              + s.substring(m+ 1);
//				else
//					s= s.substring(0, m) + '0'
//		              + s.substring(m+ 1);
//		}
//			}
//			i++;
//		}
//		System.out.println(s);
//		for(int j=0; j<s.length(); j++) {
//			if(s.charAt(j)!='0') {
//				System.out.println("0");
//				break;
//			}
//				//return 0;
//		}
	//	System.out.println("1");
		//return 1;
		
		
		
		
		
//		String s1=sc.nextLine();
//		String s2=sc.nextLine();
		
		
		
		
//		for(int i=5; i>0; i--) {
//			for(int j=i; j>0; j--) {
//				System.out.print("*"+" ");
//			}
//			System.out.println();
//		}
	}
}
//		
//		char c1[]=s1.toCharArray();
//		char c2[]=s2.toCharArray();
//		Arrays.sort(c1);
//		Arrays.sort(c2);
//		int n=c1.length;
//		int m=c2.length;
//		if(n!=m)
//			System.out.println("not anagram");
//		else {
//		for(int i=0; i<n; i++) {
//			if(c1[i]!=c2[i])
//				System.out.println("not anagram");	
//		}
//		System.out.println("anagram");
//		}
//	}
//	}
//		//int n=sc.nextInt();
//		
	   // String s=sc.nextLine();
//	    int n=s.length();
//	    int c=0;
//	    for(int i=0; i<n/2; i++) {
//	    	if(s.charAt(i)!=s.charAt(n-1-i)) {
//	    	c=1;
//	    	break;
//	    	
//	    }
//	    }
//	    if(c==0)
//	       System.out.println("palindrome");
//	    else
//	    	System.out.println("not palindrome");
		
//		int dp[]=new int[n+1];
//		dp[0]=0;
//		dp[1]=1;
//		System.out.print(dp[0]+" "+dp[1]+" ");
//		for(int i=2; i<=n; i++) {
//			dp[i]=dp[i-1]+dp[i-2];
//			System.out.print(dp[i]+" ");
//					
//		}
		
		//System.out.println(dp[n]);
//	}
//  
//}
