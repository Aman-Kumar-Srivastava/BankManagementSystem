package array;
import java.util.*;
public class kthMissingPositiveNo {

	public static void main(String args[]) {
		int k=1;
	int A[]= {3, 2, 2, 2,1};
	int N=5;
	for(int j=0; j<k; j++) {
		int max=A[0];
		int min=A[0];
		//int a=0, b=0;
	for(int i=1; i<N; i++) {
		if(max<A[i]) {
			max=A[i];
		}
		
		
	}
	for(int i=0; i<N; i++) {
		if(max==A[i]) {
			A[i]--;
		}
		
	}
//	for(int i=0; i<N; i++) {
//		System.out.print(A[i]);
//	}
	for(int i=1; i<N; i++) {
		if(min>A[i]) {
			min=A[i];
			//b=i;
		}
		
	}
	for(int i=0; i<N; i++) {
		if(min==A[i]) {
			A[i]++;
		}
		
	//A[b]=A[b]+1;
	}
	}
	int max=A[0];
	int min=A[0];
	int c=0, d=0;
	for(int i=0; i<N; i++) {
		if(max<A[i]) {
			max=A[i];
			c=i;
		}
		if(min>A[i]) {
			min=A[i];
			d=i;
		}
	}
	//Arrays.sort(A);
	System.out.print(Math.abs(A[c]-A[d]));
	}
}






















//for(int i=0; i<k; i++) {
//Arrays.sort(A);
//A[N-1]=A[N-1]-1;
//Arrays.sort(A);
//A[0]=A[0]+1;
//}
//Arrays.sort(A);
//System.out.print(Math.abs(A[N-1]-A[0]));
//	}
//}




//Coolections.sort(A);
//int res=1;
//int V=1;
//int i=0;
//while(i<N){
//	if(V*A.get(i)>=X && (V*A.get(i)<=Y ) {
//		i++;
//	}
//	else {
//		V++;
//		if(V*A.get(i)>=X)
//		res++;
//		else
//			V=V-2;
//	}
//}
//}
//return res;
