package array;

public class mergeTwoSortedArray {
	
	static void merge(int arr1[], int arr2[],int arr3[], int n, int m) {
		int i=0,j=0;
		int k=0;
		int l=0;
		while(i<n-1 && j<m-1) {
			if(arr1[i]<=arr2[i]) {
			arr3[k]=arr1[i];
			i++;
			
			}
			else {
				arr3[k]=arr2[j];
				j++;
				
			}
			k++;
	
		}
		while(i<n-1) {
			arr3[k]=arr1[i];
			i++;
			k++;
		}
		while(j<m-1) {
			arr3[k]=arr1[j];
			j++;
			k++;
		}
		
	}
static void printArray(int arr3[], int l) {
		for(int k=0; k<l-1; k++) {
			System.out.print(arr3[k]+" ");
		}
	}
	
public static void main(String args[]) {
	int arr1[]= {1, 2, 3, 4, 5};
	int n=5;
	int arr2[]= {6, 7, 8, 9};
	int m=4;
	int l=m+n;
	int arr3[]= new int[l];
	merge(arr1, arr2, arr3, n, m);
	printArray(arr3, l);
}
}
