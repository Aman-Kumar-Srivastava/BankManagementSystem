package tree;
import java.util.*;
public class BalancedBinaryTree {
	static int height(node root) {
		if(root==null)
			return 0;
			else
			return 1+ Math.max(height(root.left), height(root.right));
		}		
	static boolean balanced(node root) {
		if(root==null)
			return true;
		int lh=height(root.left);
		int rh=height(root.right);
		return (Math.abs(lh-rh)<=1 && balanced(root.left) && balanced(root.right));
	}
public static void main(String args[]) {
		
		node root=new node(100);
		root.left= new node(30);
		root.right= new node(70);
		root.left.left=new node(10);
		root.left.right=new node(20);
		root.left.left.right=new node(10);
		root.right.right=new node(70);
		System.out.println(balanced(root));
	}
}
