package tree;

public class diameterOfTree {
	static int res=0;
	static int diameter(node root) {
	if(root==null)
		return 0;
	 int lheight = height(root.left);
     int rheight = height(root.right);
     
     int ldiameter = diameter(root.left);
     int rdiameter = diameter(root.right);
     return Math.max(lheight + rheight + 1,Math.max(ldiameter, rdiameter));
	}
	static int height(node root)
    {
        if (root == null)
            return 0;
//        int lheight = height(root.left);
//        int rheight = height(root.right);
//        res=Math.max(1+lheight+rheight,res);
//       // return res;
        return (1 + Math.max(height(root.left),height(root.right)));
    }
public static void main(String args[]) {
		
//		node root=new node(100);
//		root.left= new node(30);
//		root.right= new node(70);
//		root.left.left=new node(10);
//		root.left.right=new node(20);
//		root.left.left.right=new node(10);
//		root.right.right=new node(70);
	
	node root = new node(1);
    root.left = new node(2);
    root.right = new node(3);
    root.left.left = new node(4);
    root.left.right = new node(5);
	System.out.println(diameter(root));
    //System.out.println(height(root));
    //System.out.println(res);
	}
}
