package tree;
//class node{
//	node left;
//	node right;
//	int key;
//	node(int n){
//		key=n;
//		left=right=null;
//	}
//}
public class preOrder{
	
	
	static void printpreOrder(node root) {
	if(root!=null) {
		System.out.print(root.key+" ");
		printpreOrder(root.left);
		printpreOrder(root.right);
	
		
		
	}
	}
	
public static void main(String args[]) {
	
	node root=new node(10);
	root.left= new node(20);
	root.right= new node(30);
	root.left.left=new node(40);
	root.left.right=new node(50);
	root.left.left.right=new node(60);
	root.right.right=new node(70);
	printpreOrder(root);
}
}

