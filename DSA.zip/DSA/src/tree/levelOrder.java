package tree;
import java.util.LinkedList;
import java.util.Queue;

//class node{
//			node left;
//			node right;
//			int key;
//			node(int n){
//				key=n;
//				left=right=null;
//			}
//		}
	public class levelOrder {	
		//int arr[]= {1,2,3};
		 static void queueMethod(node root) {
//levelOrder a=new levelOrder();
			 //int temp=a.arr[0];
			if(root== null)
				return;
			Queue<node> q= new LinkedList<>();
			q.add(root);
			while(q.isEmpty()==false) {
				int count=q.size();
				for(int i=0; i<count; i++) {
					node curr=q.poll();
					//if(i==0)
						System.out.print(curr.key+" ");
					if(curr.left!=null)
						q.add(curr.left);
					if(curr.right!=null)
						q.add(curr.right);
				}
				System.out.println();
			}
		}
//		static int hieght(node root) {
//			if(root==null)
//				return 0;
//				else
//				return 1+ Math.max(hieght(root.left), hieght(root.right));
//	}
			
			
//	static void kDistance(node root, int k){
//				if(root==null)
//					return ; 
//				if(k==0)
//					System.out.print(root.key+" ");	
//				else {
//					kDistance(root.left, k-1);
//					kDistance(root.right, k-1);
//				}
//	}
			
		public static void main(String args[]) {
			
			node root=new node(10);
			root.left= new node(20);
			root.right= new node(30);
			root.left.left=new node(40);
			root.left.right=new node(50);
			root.left.left.right=new node(60);
			root.right.right=new node(70);
//			int h=hieght(root);
//			System.out.println("hieght: "+h);
//			for(int i=0; i<h; i++)
//			kDistance(root, i);
			//levelOrder l=new levelOrder();
			queueMethod(root);
			//queueMethod(root);
		}

}
