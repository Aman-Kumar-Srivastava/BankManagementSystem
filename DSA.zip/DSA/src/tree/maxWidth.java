package tree;
import java.util.*;
public class maxWidth {
	static int width(node root) {
		if(root==null)
			return 0;
	int res=0;
	Queue<node> q=new LinkedList<node>();
	q.add(root);
	while(q.size()!=0) {
		int count=q.size();
		res=Math.max(res,count);
		for(int i=0; i<count; i++) {
			node curr=q.poll();
			if(curr.left!=null){
				q.add(curr.left);
			}
			if(curr.right!=null){
				q.add(curr.right);
			}
		}
	}
	return res;
	}
public static void main(String args[]) {
		
		node root=new node(100);
		root.left= new node(30);
		root.right= new node(70);
		root.left.left=new node(10);
		root.left.right=new node(20);
		root.left.left.right=new node(10);
		root.right.right=new node(70);
		System.out.println(width(root));
	}
}
