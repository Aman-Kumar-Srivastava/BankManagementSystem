package tree;

public class childSumProperty {
	static boolean CSum(node root) {
		if(root==null)
			return true;
		if(root.left==null && root.right==null)
			return true;
		int sum=0;
		if(root.left!=null)
			sum+=root.left.key;
		if(root.right!=null)
			sum+=root.right.key;
		return(root.key==sum&&CSum(root.left)&&CSum(root.right));
	}
public static void main(String args[]) {
		
		node root=new node(100);
		root.left= new node(30);
		root.right= new node(70);
		root.left.left=new node(10);
		root.left.right=new node(20);
		root.left.left.right=new node(10);
		root.right.right=new node(70);
		System.out.println(CSum(root));
	}
}
