package circularLinkedlist;


public class insertionInSortedCircularLikedlist {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
public void insertion(Node temp,int key){
	Node h=head;
	while(h.next!=head) {
         if(h.data<=key && h.next.data>key)
         temp.next=h.next;
         h.next=temp;
	}
	h=h.next;
}
	public void printNewLinkedList() {
		Node n=head;
		while(n.next!=head) {
			System.out.print(n.data+"->");
			n=n.next;
		}
	}
public static void main(String aegs[]) {
		insertionInSortedCircularLikedlist l= new insertionInSortedCircularLikedlist();
	l.head= new Node(3);
	Node second= new Node(5);
	Node third= new Node(7);
	Node last= new Node(9);
	
	l.head.next=second;
	second.next=third;
	third.next=last;
	last.next=l.head;
	Node temp= new Node(8);
    l.insertion(temp, 8);
	l.printNewLinkedList();
	
}
}
