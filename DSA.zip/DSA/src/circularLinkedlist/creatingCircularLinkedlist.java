package circularLinkedlist;

public class creatingCircularLinkedlist {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public void printdata() {
		Node n=head;
		do {
			System.out.print(n.data+" ");
			n=n.next;
		}
		while(n!=head);
	}
	public static void main(String args[]) {
		creatingCircularLinkedlist l= new creatingCircularLinkedlist();
		l.head= new Node(1);
		Node second= new Node(2);
		Node third= new Node(15);
		Node fourth= new Node(7);
		Node last=new Node(8);
		
		l.head.next=second;
		second.next=third;
		third.next=fourth;
		fourth.next=last;
		last.next=l.head;
		l.printdata();
	
	  }
}
