package linkedlist;

public class insertionInLinkedList {
	
	Node head;
	static class Node{
		int val;
		Node next;
		Node(int val){
			this.val=val;
			next=null;
		}
	}
	public void printNewLinkedList() {
		Node n=head;
		while(n!=null) {
			System.out.print(n.val+"->");
			n=n.next;
		}
		System.out.print("null");
	}
//	public void insertionAtFront(int a){
//		Node new_node= new Node(a);
//		new_node.next= head;
//		head=new_node;
//	}
//	public void insertionAfterGivenNode(Node prev_node, int a){
//		if (prev_node == null) {
//	        System.out.println(
//	            "The given previous node cannot be null");
//	        return;
//	    }
//		Node new_node= new Node(a);
//		
//		new_node.next= prev_node.next;
//		prev_node.next=new_node;
//	}
	
//	public void insertionAtLast(int a, Node fourth) {
//		Node new_node=new Node(a);
//		new_node.next=null;
//		fourth.next=new_node;
//	}
	
	
	
public static void main(String args[]) {
	insertionInLinkedList l= new insertionInLinkedList();
	l.head= new Node(7);
	Node second= new Node(8);
	Node third= new Node(2);
	Node fourth= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	//l.insertionAtFront(6);
	//l.insertionAfterGivenNode(third, 11);
	//l.insertionAtLast(9, fourth);
	l.printNewLinkedList();
	
}
}
