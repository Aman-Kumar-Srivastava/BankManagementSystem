package linkedlist;


public class NthnodeFromStarting {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public void printnthNode(int n) {
		Node node=head;
	while(n>1)	
	{
		if(node!=null)
		node=node.next;
//		else {
//		System.out.println("out of range");
//		break;
//		}
		n--;
	}
	System.out.println(node.data);
	
	}
public static void main(String args[]) {
	NthnodeFromStarting l= new NthnodeFromStarting();
	l.head=new Node(7);
    Node second=new Node(8);
    Node third= new Node(2);
	Node fourth= new Node(3);
//	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	l.printnthNode(3);
}
}
