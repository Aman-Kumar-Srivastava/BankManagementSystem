package linkedlist;

public class intersectionOfLinkedlist {
	Node head1, head2;
	Node dummy=null, tail=null;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public void intersection() {
	Node node1=head1, node2=head2;
	while(node1!=null && node2!=null) {
		if(node1.data==node2.data) {
             push(node1.data);
			node1=node1.next;
			node2=node2.next;
		}
		else if(node1.data<node2.data) {
			node1=node1.next;
		}
		else
			node2=node2.next;
	}
	}
	void push(int data) {
        Node temp = new Node(data);
        if(dummy == null) {
            dummy = temp;
            tail = temp;
        }
        else {
            tail.next = temp;
            tail = temp;
        }
    }
	public void printLinkedList(Node dummy) {
		Node n=dummy;
		while(n!=null) {
			System.out.print(n.data+"->");
			n=n.next;
		}
		System.out.print("null");
	}
	public static void main(String args[]) {
	intersectionOfLinkedlist l= new intersectionOfLinkedlist();
	l.head1= new Node(1);
	Node second= new Node(2);
	Node third= new Node(5);
	Node fourth= new Node(7);
	
	l.head1.next=second;
	second.next=third;
	third.next=fourth;
	
	l.head2= new Node(1);
	Node fifth= new Node(5);
	Node sixth= new Node(6);
	Node seventh= new Node(7);
	
	l.head2.next=fifth;
	fifth.next=sixth;
	sixth.next=seventh;
	l.intersection();
	l.printLinkedList(l.dummy);
  }
}
