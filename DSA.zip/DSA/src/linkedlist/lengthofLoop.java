package linkedlist;

import java.util.HashSet;

public class lengthofLoop {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public String findloop() {
		Node h=head;
		HashSet<Node> s=new HashSet<Node>();
		int count=0;
		String s1;
		while(h!=null) {
			if(s.contains(h)) {
				s1=String.valueOf(count);
				return s1;
			}
			s.add(h);
			count++;
			h=h.next;
		}
		return "Loop not detected";
	}
	public static void main(String args[]) {
		lengthofLoop l= new lengthofLoop();
	l.head= new Node(3);
	Node second= new Node(7);
	Node third= new Node(2);
    Node fourth=new Node(5);
	Node last= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	fourth.next=last;
	last.next=l.head;
	System.out.println(l.findloop());
}
}
