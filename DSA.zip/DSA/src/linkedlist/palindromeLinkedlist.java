package linkedlist;

public class palindromeLinkedlist {
	Node head;
	static class Node{
		int data;
		Node next;
		Node prev;
		Node(int d){
			data=d;
			next=null;
			prev=null;
		}
	}
	public int	findLength() {
		int count=0;
		Node node=head;
		while(node!=null) {
			node=node.next;
			count++;
		}
		return (count);
	}
	public String checkPalindrome(int N, Node head, Node last) {
		int n;
		Node node1=head, node2=last;
		if(N%2==0)
		n=N/2;
		else
			n=N/2+1;
		while(n>1) {
			if(node1!=null) {
				if(node1.data==node2.data) {
					node1=node1.next;
				node2=node2.prev;
				}
				else
					return "not palindrome";
			} n--;
			
		} return "palindrome";
	}
	public static void main(String args[]) {
		palindromeLinkedlist l= new palindromeLinkedlist();
	l.head= new Node(3);
	Node second= new Node(7);
	Node third= new Node(2);
    Node fourth=new Node(5);
	Node last= new Node(3);
	
	l.head.next=second;
	second.prev=l.head;
	second.next=third;
	third.prev=second;
	third.next=fourth;
	fourth.prev=third;
	fourth.next=last;
	last.prev=fourth;
	int N=l.findLength();
	System.out.println(l.checkPalindrome(N, l.head, last));
}
}
