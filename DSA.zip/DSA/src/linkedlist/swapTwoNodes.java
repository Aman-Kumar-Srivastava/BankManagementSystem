package linkedlist;

public class swapTwoNodes {
	Node head;
	static class Node{
		int data;
		Node next;
		Node prev;
		Node(int d){
			data=d;
			next=null;
			prev=null;
		}
	}
		
	public void swapping(int n, int m) {
		Node node=head;
		while(node!=null) {
			if(node.data==m) {
			node.data=n;
			node=node.next;
			}
			else if(node.data==n) {
				node.data=m;
			node=node.next;
			}
			else
				node=node.next;
		}
		Node h=head;
		while(h!=null) {
			System.out.print(h.data+"->");
			h=h.next;
		}
		System.out.print("null");
				
	}
	public static void main(String args[]) {
		swapTwoNodes l= new swapTwoNodes();
	l.head=new Node(0);
	Node second= new Node(7);
	Node third= new Node(2);
    Node fourth=new Node(6);
	Node last= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	fourth.next=last;
	l.swapping(7, 3);
	//l.printdata();
}
}
