package linkedlist;
import java.util.*;
public class removeduplicatescInUnsorted {
	Node head;
	static class Node{
		int data;
		Node next;
		Node prev;
		Node(int d){
			data=d;
			next=null;
			prev=null;
		}
	}
	
	public void removeduplicates() {
		Node node =head, prev=null;
		HashSet<Integer> h=new HashSet<>();
		
			while(node!=null) {
				if (h.contains(node.data)) {
	                prev.next = node.next;
	            }
	            else {
	                h.add(node.data);
	                prev = node;
	            }
				node=node.next;
			}	
	}
	public void printdata() {
		Node n=head;
		while(n!=null) {
			System.out.print(n.data+"->");
			n=n.next;
		}
		System.out.print("null");
	}
	public static void main(String args[]) {
		removeduplicatescInUnsorted l= new removeduplicatescInUnsorted();
	l.head=new Node(0);
	Node second= new Node(7);
	Node third= new Node(2);
    Node fourth=new Node(7);
	Node last= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	fourth.next=last;
	l.removeduplicates();
	l.printdata();
}
}
