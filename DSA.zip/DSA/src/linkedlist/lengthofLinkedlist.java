package linkedlist;
public class lengthofLinkedlist {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public void	findLength() {
		int count=0;
		while(head!=null) {
			head=head.next;
			count++;
		}
		System.out.println(count);
	}
public static void main(String args[]) {
	lengthofLinkedlist l= new lengthofLinkedlist();
	l.head=new Node(7);
    Node second=new Node(8);
    Node third= new Node(2);
	Node fourth= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	l.findLength();
}
}
