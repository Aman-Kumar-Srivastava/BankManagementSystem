package linkedlist;

public class deletionInLinkedList {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	
//	public void printNewLinkedList() {
//		Node n=head;
//		while(n!=null) {
//			System.out.print(n.data+"->");
//			n=n.next;
//		}
//		System.out.print("null");
//	}
//	public void deletionInStart() {
//		head=head.next;
//	}
	public void deletionAtGivenNode(int key) {
		Node node=head;
		Node temp= new Node(0);
		temp.next=head;
		
		while(node!=null) {
			if(node!=null && node.data!=key) {
				temp=node;
			node=node.next;
		}
			else 
			{
				 temp.next = node.next;
		}
		}
		while(node!=null) {
			System.out.print(node.data+"->");
			node=node.next;
		}
		System.out.print("null");
		
	}
//	public void deletionInLast(Node third) {
//	third.next=null;
//}
//	
public static void main(String aegs[]) {
	deletionInLinkedList l= new deletionInLinkedList();
	l.head= new Node(7);
	Node second= new Node(7);
	Node third= new Node(7);
	Node fourth= new Node(9);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	//l.deletionInLast(fourth);
	l.deletionAtGivenNode(7);
	//l.deletionInStart();
	//l.printNewLinkedList();
	
}
}
