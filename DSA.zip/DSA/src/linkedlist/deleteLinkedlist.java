package linkedlist;

import linkedlist.deletionInLinkedList.Node;

//import linkedlist.deletionInLinkedList.Node;

public class deleteLinkedlist {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			this.data=d;
			next=null;
		}
	}
	
//	public void printNewLinkedList() {
//		Node n=head;
//		while(n!=null) {
//			System.out.print(n.data+"->");
//			n=n.next;
//		}
//		System.out.print("null");
//	}
	public void deletingLinkedlist() {
		while(head!=null)
			head=head.next;
	
	}
	
public static void main(String args[]) {
	deleteLinkedlist l= new deleteLinkedlist();
    l.head=new Node(7);
    Node second=new Node(8);
    Node third= new Node(2);
	Node fourth= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	l.deletingLinkedlist();
	System.out.print(l+"deleted");
	//l.printNewLinkedList();
}
}
