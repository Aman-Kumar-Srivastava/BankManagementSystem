package linkedlist;

import linkedlist.NthnodeFromStarting.Node;

//import linkedlist.searchinLinkedlist.Node;

public class NthnodefromLast {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public int	findLength() {
		int count=0;
		Node node=head;
		while(node!=null) {
			node=node.next;
			count++;
		} return count;
	}
public void findnthNodefromLast(int d, int N) {
	int n=N-d+1;
	Node node=head;
	while(n>1) {
		if(node!=null)
		node=node.next;
		n--;
	}
System.out.println(node.data);
}
public static void main(String args[]) {
	NthnodefromLast l= new NthnodefromLast();
	l.head=new Node(7);
    Node second=new Node(8);
    Node third= new Node(2);
	Node last= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=last;
	int N=l.findLength();
	//System.out.println(N);
	l.findnthNodefromLast(3,N);
}
}
