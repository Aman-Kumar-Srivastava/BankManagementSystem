package linkedlist;
//import java.util.*;

public class printLinkedList {
	Node head;
	 static class Node{
		 int data;
		 Node next;
		 Node(int d){
			 data=d;
			 next=null;
		 }
	 }
	public void printdata() {
		Node n=head;
		while(n!=null) {
			System.out.print(n.data+"->");
			n=n.next;
		}
		System.out.print("null");
	}
public static void main(String []args) {
	printLinkedList l= new printLinkedList();
	l.head=new Node(7);
	Node second= new Node(9);
	Node third=new Node(4);
	Node fourth=new Node(2);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	l.printdata();
}
}
