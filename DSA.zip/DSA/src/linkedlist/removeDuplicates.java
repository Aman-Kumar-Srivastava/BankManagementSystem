package linkedlist;

public class removeDuplicates {
	Node head;
	static class Node{
		int data;
		Node next;
		//Node prev;
		Node(int d){
			data=d;
			next=null;
			//prev=null;
		}
	}
	
	public void removeduplicates() {
		Node node =head, prev=null;
		if(node!=null && node.data==node.next.data) {
		 head = node.next;
		}
		else {
			while(node!=null && node.data!=node.next.data) {
				prev=node;
				node=node.next;
			}
			prev.next = node.next;	
		}
	}
	public void printdata() {
		Node n=head;
		while(n!=null) {
			System.out.print(n.data+"->");
			n=n.next;
		}
		System.out.print("null");
	}
	public static void main(String args[]) {
	removeDuplicates l= new removeDuplicates();
	l.head=new Node(0);
	Node second= new Node(1);
	Node third= new Node(2);
    Node fourth=new Node(2);
	Node last= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	fourth.next=last;
	l.removeduplicates();
	l.printdata();
}
}
