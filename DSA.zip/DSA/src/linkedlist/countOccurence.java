package linkedlist;

public class countOccurence {
	Node head;
	static class Node{
	int data;
	Node next;
	Node(int d){
		data=d;
		next=null;
	}
	}
public int counting(int key) {
	Node node=head;
	int count=0;
	while(node!=null) {
		if(node.data==key) {
			count++;
		}
		node=node.next;
	} return (count);
}
public static void main(String args[]) {
	 countOccurence l= new  countOccurence();
	l.head=new Node(2);
    Node second=new Node(8);
    Node third= new Node(2);
    Node fourth=new Node(2);
	Node last= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	fourth.next=last;
	System.out.println(l.counting(2));
	//l.counting(2);
}
}
