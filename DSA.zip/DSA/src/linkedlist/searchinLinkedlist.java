package linkedlist;

public class searchinLinkedlist {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public boolean searching(int key) {
	Node node=head;
	while(node!=null) {
		if(node.data==key)
			return true;	
		node=node.next;
	}
	return false;
}
	public static void main(String args[]) {
		searchinLinkedlist l= new searchinLinkedlist();
	l.head=new Node(7);
    Node second=new Node(8);
    Node third= new Node(2);
	Node fourth= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	//l.searching(8);
	 if (l.searching(8))
         System.out.println("Yes");
     else
         System.out.println("No");
}
}