package linkedlist;

public class printIntersectionPoint {
	Node head1, head2;
	Node dummy=null, tail=null;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public void intersectionPoint() {
	Node node1=head1, node2=head2;
	while(node1!=null && node2!=null) {
		if(node1.data==node2.data) {
            System.out.println(node1.data);
            break;
		}
		else if(node1.data<node2.data) {
			node1=node1.next;
		}
		else
			node2=node2.next;
	}
	}
	public static void main(String args[]) {
		printIntersectionPoint l= new printIntersectionPoint();
		l.head1= new Node(1);
		Node second= new Node(2);
		Node third= new Node(15);
		Node fourth= new Node(7);
		
		l.head1.next=second;
		second.next=third;
		third.next=fourth;
		
		l.head2= new Node(0);
		Node fifth= new Node(3);
		Node sixth= new Node(15);
		Node seventh= new Node(7);
		
		l.head2.next=fifth;
		fifth.next=sixth;
		sixth.next=seventh;
		l.intersectionPoint();
	  }
}
