package linkedlist;
public class movelastNodetofront {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public void movelasttofront(Node last, Node fourth) {
	last.next=head;
	head=last;
	fourth.next=null;
	}
	public void printdata() {
		Node n=head;
		while(n!=null) {
			System.out.print(n.data+"->");
			n=n.next;
		}
		System.out.print("null");
	}

	public static void main(String args[]) {
		movelastNodetofront l= new  movelastNodetofront();
	l.head=new Node(0);
	Node second= new Node(7);
	Node third= new Node(2);
   Node fourth=new Node(6);
	Node last= new Node(3);
	
	l.head.next=second;
	second.next=third;
	third.next=fourth;
	fourth.next=last;
	l.movelasttofront(last, fourth);
	l.printdata();	
	}
}
