package DP;

public class longestIncreasingSubsquenceSum {
	static int LISsum( int arr[], int n) {
		int lis[]=	new int[n];
		lis[0]=arr[0];
		for(int i=1; i<n; i++) {
			lis[i]=arr[i];
			for(int j=0; j<i; j++) {
			if(arr[i]>arr[j])
				lis[i]=Math.max(lis[i], lis[j]+arr[i]);
			}
		}
		int res=lis[0];
		for(int i=1; i<n; i++) {
			res=Math.max(res, lis[i]);
		}
		return res;
		}
	public static void main(String args[]) {
		int arr[]= {3,4,2,8,10,5,1}, n=7;
		System.out.println(LISsum(arr, n));
		}
	}
