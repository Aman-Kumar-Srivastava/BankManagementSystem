package DP;

public class editDistance {
	static int findDistance(String s1,String s2, int n, int m) {
		int dp[][]=new int[n+1][m+1];
		for(int i=0; i<=n; i++)
			dp[i][0]=i;
		for(int j=1; j<=m; j++)
			dp[0][j]=j;
		for(int k=1; k<=n; k++) {
			for(int l=1; l<=m; l++) {
				if(s1.charAt(k-1)==s2.charAt(l-1))
					dp[k][l]=dp[k-1][l-1];
				else
					dp[k][l]=1+Math.min((Math.min(dp[k][l-1], dp[k-1][l])),dp[k-1][l-1]);
			}
		}
		return dp[n][m];
		
//		if(s1.charAt(n-1)==s2.charAt(m-1)) {
//		return findDistance(s1,s2, n-1, m-1);
//		}
//		else
//		return 1+Math.min((Math.min(findDistance(s1,s2, n-1, m-1),findDistance(s1,s2, n, m-1))),findDistance(s1,s2, n-1, m));
	}
public static void main(String args[])
{
	String s1="323";
	String s2="232";
	int n=s1.length();
	int m=s2.length();
	System.out.println(findDistance(s1,s2, n, m));
}
}
