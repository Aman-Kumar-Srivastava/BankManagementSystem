package DP;

public class longestCommonSubsequence {
	static int res=0;
	static int LCS(String s1, String s2,int n, int m) {
	
	if(n==0) return 0;
	if(m==0) return 0;
	if(s1.charAt(n-1)==s2.charAt(m-1))
		res=1+LCS(s1,s2,n-1,m-1);
	else
		res=Math.max(LCS(s1,s2,n-1,m),LCS(s1,s2,n,m-1));
	return res;
	}
	public static void main(String args[]) {
		String a="abcdef";
		String b="abdrte";
		int n=a.length();
		int m=b.length();
		System.out.println(LCS(a, b,n,m));
		}
	}


//


//class student{
//	static int i=1;
//	String r;
//	Student(String name){
//		r=name;
//		i++;
//	}
// return i+ ":" +name;
//}



















