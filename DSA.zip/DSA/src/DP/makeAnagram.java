package DP;

public class makeAnagram {
		static int count(String s) {
	     int n=s.length();
//	     int k1, k2;
//	     if(n%2==0) {
//	    	 k1=n/2-1;
//	    	 k2=n/2;
//	     }
//	     else {
//	    	 k1=n/2-1;
//	         k2=n/2+1;
//	     }
//	     String s1=s.substring(0,k1+1);
//	     String s2=s.substring(k2,n);
//	     String s3="";
//	     int k=s2.length();
//	     for(int i=k-1; i>=0; i--) {
//           s3+=s2.charAt(i);
//	     }
	     int count=0;
	   for(int i=0; i<n/2; i++) {
		   if(s.charAt(i)!=s.charAt(n-1-i))
			   count++;
	   }
	   return count;
			//return findDistance(s1,s3);
		}
//			static int findDistance(String s1,String s2) {
//				int n=s1.length();
//				int m=s2.length();
//				int dp[][]=new int[n+1][m+1];
//				for(int i=0; i<=n; i++)
//					dp[i][0]=i;
//				for(int j=1; j<=m; j++)
//					dp[0][j]=j; 
//				for(int k=1; k<=n; k++) {
//					for(int l=1; l<=m; l++) {
//						if(s1.charAt(k-1)==s2.charAt(l-1))
//							dp[k][l]=dp[k-1][l-1];
//						else
//							dp[k][l]=1+Math.min(Math.min(dp[k][l-1], dp[k-1][l]),dp[k-1][l-1]);
//					}
//				}
//				return dp[n][m];
		 int n=s.length();
	     int k1, k2;
	     if(n%2==0) {
	    	 k1=n/2-1;
	    	 k2=n/2;
	     }
	     else {
	    	 k1=n/2-1;
	         k2=n/2+1;
	     }
	     String s1=s.substring(0,k1+1);
	     String s2=s.substring(k2,n);

				int sum=0;
				int n=s1.length();
				
				int arr[]=new int[10];
				for(int i=0; i<n/2; i++) {
				arr[s1.charAt(i)-48]++;
				arr[s2.charAt(i)-48]--;
				}
				for(int i=0; i<10; i++) {
					sum+=Math.abs(arr[i]);
				}
				return sum/2;
		//	}
		public static void main(String args[]){
			String s="32232";
			System.out.println(count(s));
		}
		
}
