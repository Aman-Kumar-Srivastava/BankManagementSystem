package practice;
import java.util.*;
public class goodSubsequence {

	public static void main(String args[]) {
		int arr[]= {1,9,14,2,17,14,5,18};
		int n=arr.length;
		ArrayList al=new ArrayList();
		int min=arr[0];
		for(int i=0; i<n; i++) {
			min=arr[i];
			ArrayList bl=new ArrayList();
			for(int j=0; j<=i; j++) {
				min=Math.min(min, arr[j]);
			if(Math.abs(min-arr[j])<=10)
				bl.add(arr[j]);
			}
//			bl.add(arr[i]);
			if(bl.size()>al.size())
				al=new ArrayList(bl);
		}
		System.out.print(al);
	}

}
