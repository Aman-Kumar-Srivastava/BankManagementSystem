package practice;
import java.util.*;
public class noOfSlots {

	public static void main(String args[]) {
		int n=4;
		int l[]= {1,4,9,23};
		int r[]= {3,9,22,1000000};
		List<List<Integer>> al=new ArrayList<>();
		List<Integer> a=new ArrayList<>();
		if(l[0]!=0) {
			a.add(0);
			a.add(l[0]);
			al.add(a);
		}
		for(int i=1; i<n; i++) {
			a=new ArrayList<>();	
		if(l[i]>r[i-1])	{
			a.add(r[i-1]);
			a.add(l[i]);
			al.add(a);
		}
		}
		if(r[n-1]<1000000) {
		a=new ArrayList<>();
		a.add(r[n-1]);
		a.add(1000000);
		al.add(a);
		}
		System.out.println(al);	
		System.out.println((char)97);
	}

}
