package practice;
import java.util.*;
public class badNumbers {

public static void main(String args[]) {
	int L=1;
	int R=74;
    //int a=0, b=0;
    int count=0; 
//    count=solveSec(R)-solveSec(L-1);
//    System.out.println(count);
    int arr[]= {7,98,56,43,45,23,12,8};
    int m=arr.length;
    int k=54;
    List<Integer> al=new ArrayList<Integer>();
//    for(int i=L; i<=R; i++) {
    for(int i=0; i<m; i++) {
		String s=Integer.toString(arr[i]);
        int n =s.length();
		if(Math.abs((int)s.charAt(0)-(int)s.charAt(n-1))==1 && arr[i]<k)
			al.add(arr[i]);
			//count++;
	}
    System.out.println(al);
}
}
//  public static int solveSec(int y){
//    		int ans=0,t=y;
//    		if(y<10)
//    			return y;
//    		int l=y%10;
//    		int f=0;
//    		while(y>0) {
//    		f=y%10;
//    		y=y/10;
//    		}
//    		if(f<=l)
//    			ans=9+t/10;
//    		else
//    			ans=8+t/10;
//    		
//    		return ans;	
//    		}
//}
    	   
//	for(int i=L; i<=R; i++) {
//		String s=Integer.toString(i);
//        int n =s.length();
//		if(s.charAt(0)==s.charAt(n-1))
//			count++;
//	}
//    int t1=Integer.toString(L).length();
//    int t2=Integer.toString(R).length();
//    while(t1>0) {
//    	L=L/10;
//    	a++;
//    }
//    while(t2>0) {
//    	R=R/10;
//    	b++;
//    }
    
	//System.out.println(count);
//}


//
//1 2 3 4 5 6 7 8 9                 ---9
//11 22 33 44 55 66 77 88 99        ---9
//101 111 121 131 141 151 161 171 181 191    ---10
//202 212 222 232 242 252 262 272 282 292