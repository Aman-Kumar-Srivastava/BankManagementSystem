package string;

public class book {
	static int findbook(String s, int n) {
		int res=0;
		return res;
	}
	public static void main(String args[]) {
		String a="boklokiubookijhbljolok";
		int n=a.length();
		System.out.println(findbook(a, n));
		}
	
}
