package oracle;
import java.util.*;
public class practice1 {

	public static void main(String[] args) {

		List<Integer> al=new ArrayList();
		al.add(null);
		al.add(null);
		al.add(1);
		al.add(9);
		al.add(3);
		Collections.sort(al);
        System.out.println(al);

	}

}
