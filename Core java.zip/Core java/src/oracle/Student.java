package oracle;


//class Course{
//	String coursename;
//}
class MyClass{
	private int var1=100;
}
public class Student {
	char sgrade;
	String stuName;
	public static void main(String args[]) {
//		Student s=new Student();
//	//	s.stuName=args[0];
//		//Course c=new Course();
//		//c.coursename=args[1];
//	//	System.out.println(s.stuName+"is studying"+c.coursename);
//		System.out.println("["+s.stuName+"--"+s.sgrade+"]");
		boolean b=false;
		int c=0;
		do {
		++c;
		if(c>3) {
			b=true;
			System.out.println(c);
		}
		}
		while(b==false);
	}

}
