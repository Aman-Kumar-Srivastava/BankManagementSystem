package oracle;
import java.util.*;
//class app{
//	public void docal(int[] arr) {
//		arr[0]=100;
//		arr[1]=150;
//		System.out.println(" ");
//	}
//}
 //class App {
//	String msg="Hello Java!";
//	public void sayMas() {
//		System.out.println(practice.msg);
//		
//	}
//	private String name ="John";
//	public void display() {
//		System.out.print(name);
//		
//	}
 //}
//class myclass{
//	private int var1=100;
//	public int var2=200;
//	public void docal() {
//		var1=100*2;
//		var2=200*2;
//		
//	}
//}
 public class practice{
	public static void main(String args[]) {
		int a[]=new int[3];
		a[2]=75;
		a[0]=25;
		a[1]=50;
		List l=new ArrayList();
		l.add(2,75);
		l.add(0,25);
		l.add(1,50);
		
		for(int am: a ) {
			System.out.println(am+"% ");
		}
		for(int e: l) {
			System.out.println(e+"% ");
		}
//		double a=75.25;
//		if(a>50 && a<70)
//			System.out.println("C");
//		else if(a>=70 && a<90)
//			System.out.println("B");
////	App ap=new App();
//	System.out.println(ap.display());

//	myclass m=new myclass();
//	m.docal();
//	System.out.println(m.var1+":"+m.var2);
//	
//	int[] arr= {1,2,3,4,5};
//	int n=arr.length-1;
//	do{
//		System.out.println(arr[n]);
//	}
//	while(n-->0);
	
	
	
	
	
	
	
//		String test="a";
//		for(;test.compareTo("aaa")==0; test=test+"a")
//			System.out.println(test.length()+" ");
//		System.out.println(test);
//		int [] num=new int[2];
//		num[0]=5;
//		num[1]=10;
//		for(int x: num) {
//			System.out.print(x+" ");
//		}
//		app a=new app();
//		a.docal(num);
//		for(int x: num) {
//			System.out.print(x+" ");
		
		
//		}
//	}
	
	
	}
	}