package Exception;

public class Error {
public static void main(String args[]) {
	while(true) {
		System.out.println("sandipan boka");
	}
}
}
