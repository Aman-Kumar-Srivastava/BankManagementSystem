package Exception;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class UnderstandingExceptions {

	
	public static void main(String args[]) {
		//int a=90/0;
		try {
			int b=12/0;
//			int a=50/0;//ArithmeticException 
//			
//			String s=null;  
//			System.out.println(s.length());//NullPointerException  
//			
//			String s1="abc";  
//			int i=Integer.parseInt(s1);//NumberFormatException 
//			
//			int a1[]=new int[5];  
//			a1[10]=50; //ArrayIndexOutOfBoundsException  
		}
		catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("moving forward");
		PrintWriter pw;  
        try {  
            pw = new PrintWriter("jtp.txt"); //may throw exception   
            pw.println("saved");  
        }  
// providing the checked exception handler  
 catch (FileNotFoundException e) {  
              
            System.out.println(e);
            System.out.println("file not found");
        }
        System.out.println("File saved sucessfully");
	
	 try{    
         int a[]=new int[5];    
         a[5]=30/0;    
        }    
        catch(ArithmeticException e)  
           {  
            System.out.println("Arithmetic Exception occurs");  
           }    
        catch(ArrayIndexOutOfBoundsException e)  
           {  
            System.out.println("ArrayIndexOutOfBounds Exception occurs");  
           }    
        catch(Exception e)  
           {  
            System.out.println("Parent Exception occurs");  
           }
	 
	 try{    
         int a[]=new int[5];    
         
         System.out.println(a[10]);  
        }    
        catch(ArithmeticException e)  
           {  
            System.out.println("Arithmetic Exception occurs");  
           }    
        catch(ArrayIndexOutOfBoundsException e)  
           {  
            System.out.println("ArrayIndexOutOfBounds Exception occurs");  
           }    
        catch(Exception e)  
           {  
            System.out.println("Parent Exception occurs");  
           }
//	 try{    
//		    int a[]=new int[5];    
//		    a[5]=30/0;    
//		   }    
//		   catch(Exception e){System.out.println("common task completed");}    
//		   catch(ArithmeticException e){System.out.println("task1 is completed");}    
//		   catch(ArrayIndexOutOfBoundsException e){System.out.println("task 2 completed");}    
	 
	}
}
