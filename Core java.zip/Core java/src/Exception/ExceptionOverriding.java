package Exception;

import java.io.IOException;

import javax.imageio.IIOException;

class Parent{   
	  
	  // defining the method   
	  void msg() {  
	    System.out.println("parent method");  
	    }    
	}    
	    
	public class ExceptionOverriding extends Parent{    
	  
	  // overriding the method in child class  
	  // gives compile time error  
		//void msg() throws IOException{  
	  void msg() throws ArithmeticException{    
	    System.out.println("TestExceptionChild");    
	  }  
	  
	  public static void main(String args[]) {    
	   Parent p = new ExceptionOverriding();    
	   p.msg();    
	  }    
	}
	//If the superclass method does not declare an exception, subclass overridden 
	//method cannot declare the checked exception but can declare unchecked exception.
	//If the superclass method declares an exception, subclass overridden method can declare 
	//the same subclass exception or no exception but cannot declare parent exception
