package MultiThreading;


	class MyThread extends Thread{    
	    public void run(){    
	        System.out.println("shut down hook task completed..");    
	    }    
	}
	class Thread2 extends Thread{
		public void run(){    
	        System.out.println("shut down hook task in MyThread1 is completed..");    
	    }
	}
	    
	public class ShutDownHook{    
	public static void main(String[] args)throws Exception {    
	    
	Runtime r=Runtime.getRuntime();    
	r.addShutdownHook(new MyThread());
	
	        
	System.out.println("Now main sleeping... press ctrl+c to exit");  
	
	try{Thread.sleep(3000);}catch (Exception e) {} 
	
	Thread2 m=new Thread2();
	m.run();
	Runtime.getRuntime().exec("notepad");
	 System.out.println(Runtime.getRuntime().availableProcessors());
	 //Runtime r=Runtime.getRuntime();  
	  System.out.println("Total Memory: "+r.totalMemory());  
	  System.out.println("Free Memory: "+r.freeMemory());  
	}
	
	 
}
