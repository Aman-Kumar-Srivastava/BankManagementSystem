package MultiThreading;

import java.util.List;
import java.util.Map;

class MyThread2 implements Runnable {

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println("Hi");
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

}

public class MyThread1 extends Thread {

	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println("Hello");
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	public static void main(String args[]) {
		MyThread1 obj = new MyThread1();
		//MyThread1 obj2=new MyThread1();
		MyThread2 obj1 = new MyThread2();
		Thread thread = new Thread(obj1);
		obj.start();
		System.out.println("-----obj");
//		obj2.start();
		thread.start();
		thread.run();
	}
}



//String str[]=s.split(",");
//int l=str.length;
//Map<String, Integer> map=new HashMap();
//for(int i=0; i<l; i++) {
//	if(map.containsKey(str[i])) {
//		map.put(, null)
//		
//		
//		
//		
//		char[] c= {'a','b','c'};
//		List<Character> al=new ArrayList<>();
//		for(int i=0; i<c.length; i++) {
//			al.add(c[i]);
//		}
//	}
//}
//
//
//
//config.xml we can declare beans
//using setter and constructor injection
//
//init()
//and destory()
//service
//repository
//
//
//project build tool
//it setup the project articheture
//is clean all the project and then build it again
//to depoy and run the project





