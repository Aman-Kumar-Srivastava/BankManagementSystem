package MultiThreading;

class Table{  
//synchronized
synchronized static void printTable(int n){//method not synchronized 
	//System.out.println(n+"----");
	// synchronized(this) {
   for(int i=1;i<=5;i++){  
     System.out.println(n*i);  
     try{  
      Thread.sleep(400);  
     }
     catch(Exception e){System.out.println(e);}  
   }  
	// }
 }  
}  
  
class MyThread11 extends Thread{  
Table t;  
MyThread11(Table t){  
this.t=t;  
}  
public void run(){  
t.printTable(5);  
}  
  
}  
class MyThread22 extends Thread{  
Table t;  
MyThread22(Table t){  
this.t=t;  
}  
public void run(){  
t.printTable(100);
}  
}  
class MyThread33 extends Thread{    
public void run(){    
Table.printTable(10);
}    
}    
class MyThread44 extends Thread{    
public void run(){    
Table.printTable(1000); 
}    
}    
class SynchronizationExample{  
public static void main(String args[]){  
Table obj = new Table();//only one object  
MyThread11 t1=new MyThread11(obj);  
MyThread22 t2=new MyThread22(obj);  
MyThread33 t3=new MyThread33(); 
MyThread44 t4=new MyThread44();
t1.start();  
t2.start();  
t3.start();
t4.start();
}  
}
