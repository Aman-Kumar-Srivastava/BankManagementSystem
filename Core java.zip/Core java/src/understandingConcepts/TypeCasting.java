package understandingConcepts;

public class TypeCasting {

	public static void main(String args[]) {
//		byte b=1;
//		b+=7;
//		System.out.println(b);
//		b=(b+3);
//		System.out.println(b);
		int x=16;
		System.out.println(16);
	    byte y=016;
		System.out.println(y);
	}

}
