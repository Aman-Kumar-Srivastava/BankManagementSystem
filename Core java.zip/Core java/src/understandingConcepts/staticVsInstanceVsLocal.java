package understandingConcepts;

public class staticVsInstanceVsLocal {
	
//	Java language uses variables in different scopes: static scope, local scope, block scope. 
//	Java has different ways of storing data either as primitive data types or as Objects. 
//	Class specifies type of a object. Static variable is defined generically for the entire class and not for a specific object.
//	Hence Static variables belong to a class and hence has the same value for all objects of the class. 
//	Instance (object) variables belong to a specific object.
//
//	Static variable	Instance variable      		``
//	A static variable is a property of a class.	An instance variable is a property of an instance.
//	A static variable is created only once when the classloader loads the class.	
//	An instance variable is created everytime an instance is created.
//	A static variable is used when you want to store a value that represents all the instances like count, sum, average etc.
//	An instance variable is used to store a value that represents property of single instance.
	//static variable
	static int countOfStudents;
	//instance variable
	String Id;

			public static void main(String args[]){
				staticVsInstanceVsLocal obj = new staticVsInstanceVsLocal();
				//Assigning to static variable
				staticVsInstanceVsLocal.countOfStudents = 100;
				//Assigning to instance variable
				obj.Id="11Nov2017_3578923";
				String name="AMAN";//simple local variable. it is not instance and not static.
				System.out.println(staticVsInstanceVsLocal.countOfStudents+" :::: static variable");
				System.out.println(obj.Id+" :::: instance variable");
				System.out.println(name+" :::: local variable");
			}
		    
	

}
