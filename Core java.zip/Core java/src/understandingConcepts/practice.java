package understandingConcepts;


import java.util.*;
class student{
	//int q=999;
	 int rollno;
	 String name;
	 float fee;
	public student(int rollno, String name, float fee){
		this.rollno=rollno;
		this.name=name;
		this.fee=fee;
	}
		public int getRollno() {
		return rollno;
		}
		public void setRollno(int rollno) {
			this.rollno=rollno;
		}
		public String getName() {
			 return name;
		 }
		public void setName(String name) {
			this.name=name;
	    }
		public float getFee() {
			 return fee;
		 }
		public void setFee(String name) {
			this.fee=fee;
	    }
//	void display(){System.out.println(rollno+" "+name+" "+fee);
//	}  
}


public class practice{
	
	List<student> emp=new ArrayList<>();
	
	public void addEmployee(student employee) {
        emp.add(employee);
    }
	public void searchbyName(String name) {
        for(student employee:emp) {
            if(employee.getName().equals(name)) {
                System.out.println(employee.getRollno()+" "+ employee.getFee());
            }
        }
    }
	
	public static void main(String args[]) {
		List<student> al= new ArrayList<>();
		  practice p=new practice();
	   p.addEmployee(new student(1,"aman",123.45f));
	   p.searchbyName("aman");
	   // practice p=new practice();
		
		
		   al.add(new student(1,"aman",123.45f));
	    al.forEach(s-> System.out.println(s.rollno));
	    
	    
	    StringTokenizer st1= new StringTokenizer("how : are : you", " : ", true);
	    System.out.println(st1.countTokens());
	    while(st1.hasMoreTokens()) {
	    	 System.out.println(st1.nextToken());
	    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	int id;
//	String company;
//	float salary;
//	student stu;
//	practice(int id, String company, float salary, student stu){
//		this.id=id;
//		this.company=company;
//		this.salary=salary;
//		this.stu=stu;
//	}
//	void display(){System.out.println(id+" "+company+" "+salary+" "+stu.fee);
//	}
	
//	static int rem;
//	int res;
//	
//	void result() {
//		practice par=new practice();
//		int res2=900;
//		System.out.println("static var ::: "+ rem);
//		System.out.println("instance var ::: "+ par.res);
//		System.out.println("local var ::: "+ res2);
//		}
//	int w=980;
//	public static void main(String args[]) {
//		student st=new student(111,"aman",15000.000f);
//		practice par=new practice(52123394,"hcl",28000.09f,st);
//		par.display();
//		
//		System.out.println(par.w);
//		System.out.println(par.q);
		
		
//		student st1=new student(1,"aman",56.890f);
//		student st2=new student(0,"aman1",589.890f);
//		st1.display();
//		st2.display();
////		int rs=rem;
//		practice par=new practice();
//		//int res1=par.res;
//		int res2=900;
//
//		{				
//		System.out.println("static var ::: "+ rem++);
//		System.out.println("instance var ::: "+ par.res++);
//		System.out.println("local var ::: "+ res2++);
//		System.out.println("instance var ::: "+ par.res++);
//		System.out.println("local var ::: "+ res2++);
//	    par.result();
//		}
////		practice par=new practice();
////		//int res1=par.res;
////		int res2=890;
//		System.out.println("static var ::: "+ rem++);
//		System.out.println("instance var ::: "+ par.res);
//		System.out.println("local var ::: "+ res2);
//		int i=10;
//		do {
//			System.out.println(i);			
//		}
//		while(i>10);
//		int arr[]= {1,3,5,6,7,8,9,0,2,3,4,5};
//		
//		for(int i: arr) {		
//			if(i==5)
//				continue;
//			System.out.print(i+" ");
//		}
}
	

}
