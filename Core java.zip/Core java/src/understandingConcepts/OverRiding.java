package understandingConcepts;

class Function {
    public void add(Function f) {
        f.addMe(this);
        System.out.println("add function");
    }

    public void addMe(Function f) {
    	System.out.println("addMe function");
        // Default case
        //throw NotImplementedException();
    }
    public void addMe(Logarithmic log) {
        // Code that handles the real
    	System.out.println("addMe log");
    }
}

class Logarithmic extends Function {
    // This object supports adding
    public void add(Function f) {
        f.addMe(this);
        System.out.println("f.add log extends func");
    }
}

class Parent1 {
	  public void foo(Parent1 arg) {
	    System.out.println("foo in ParentFunction");
	  }
	}
	class Child1 extends Parent1 {
		public void foo(Parent1 arg) {
		    System.out.println("foo in Child(Parent)");
		    arg.foo(this);
		  }
		public void foo(Child1 arg) {
	    System.out.println("foo in ChildFunction");
	  }  
	}

class Parent{
	int x=100;
	void run() {
		int a=10;
		int b=12;
		System.out.println((a+b)*10);
		int c=5;
		System.out.println(c*10);
		
	}
}
class Child extends Parent{
	int x=200;
	@Override
	void run() {
		int c=5;
		System.out.println(c*25);
	}
}
public class OverRiding {

	public static void main(String args[]) {
		Parent p=new Parent();
		Child c=new Child();
		Parent p1=new Child();
//		Child c1 = (Child) new Parent();
//		c1.run();
//		System.out.println(c1.x);
		p.run();
		c.run();
		p1.run();
		System.out.println(p1.x+"------");
		System.out.println(p.x+"------");
		System.out.println(c.x+"------");
		
		
//		  Child1 f = new Child1();
//		  Parent1 g = new Child1();
//		  f.foo(new Parent1());
//		  f.foo(new Child1());  
//		  g.foo(new Parent1());
//		  g.foo(new Child1());
		  
		  Logarithmic log = new Logarithmic();
		  log.add(new Function()); 
		  log.add(new Logarithmic()); 

		  Function f1 = log;
		  f1.add(new Function()); 
		  f1.add(new Logarithmic()); 
	}

}
