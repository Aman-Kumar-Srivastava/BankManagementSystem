package understandingConcepts;

public class datatypes {

	public static void main(String args[]) {
		int x=10;
		int y=0100;
		int z=0x1e0;
		double $_d=10e2;
		float f=10e2f;
		char c = 65533;
		char c1='\u0111';
		int e=1_2_3__4;
		float f1=100L;
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		System.out.println($_d);
		System.out.println(c+" "+f+" "+c1);
		System.out.println(e+" "+f1);
		System.out.println("*****************");
		System.out.println("*****************");
		System.out.println("Arrays");
		
		int [] a= {2,3,9,0},b[]= {{4,5},{7,8}};
		System.out.println(a.length+" "+b.length);
		int [][]b1=new int[1][];
		System.out.println(b1[0]);
		int[][][] a1={{{10,20,30},{40,50}},{{60},{70,80},{90,100,110}}};
		System.out.println(a1[1][1][0]);
	
//		new int[]{10,20,30,40};
		
		{
			System.out.println(sum(new int[]{10,20,30,40}));//100
			}
	}
			public static int sum(int[] x)
			{
			int total=0;
			for(int x1:x)
			{
			total=total+x1;
			}
			return total;
			}
		
	

}
