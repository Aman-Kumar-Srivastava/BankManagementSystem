package understandingConcepts;

public class OverLoading {

	public static
	    int foo() { 	
		 return 15;
	    
	}
	
	public static
	    int foo( int a) { return a; }
	    
	public
	    static void main(String args[]) {
		System.out.println(foo());
		System.out.println(foo(10));
	}
	}
