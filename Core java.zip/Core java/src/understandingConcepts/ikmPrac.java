package understandingConcepts;
//import java.util.*;
import java.io.*;
import java.util.StringTokenizer;
public class ikmPrac {

	public static void main(String args[]) {
//		java.util.Random r=new java.util.Random();
//		int res=r.nextInt(7);
//		System.out.println(res);
//		List<String> l=new ArrayList<>();
//		l.add("1");
//		l.add("2");
//		l.add(0,"3");
//		l.add(1,"4");
//		System.out.println(l);
		
//		Integer n1=new Integer(1);
//		Integer n12=new Integer(1);
//		n1+=1;
//		System.out.println(n1);System.out.println(n12);
		
		
		StringTokenizer t1=new StringTokenizer("XX YY ZZ"," ");
		do {
			System.out.println(t1.nextToken());
		}
		while(t1.hasMoreTokens());
	}

}
