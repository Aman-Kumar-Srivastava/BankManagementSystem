package producerConsumer;

public class MainMethod {

	public static void main(String args[]) {
		Company com = new Company();
		Producer pod = new Producer(com);
		Consumer cons = new Consumer(com);
		pod.start();
		cons.start();
	}

}
