package producerConsumer;

public class Consumer extends Thread {

	Company c;

	Consumer(Company c) {
		this.c = c;
	}

	public void run() {
		try {
			while (true) {
				this.c.consume_item();
				try {
					Thread.sleep(1000);
				} catch (Exception e) {

				}
			}
		} catch (Exception e) {

		}
	}

}
