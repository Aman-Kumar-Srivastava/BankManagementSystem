package java8;

public class LambdaTest {

	void methodCalculator() {
		Calculator cal;
		cal =(i,j)-> i*j;
		System.out.println("multiplication: "+cal.calculate(4,5));
		cal=(i,j)->i+j;
		System.out.println(cal.calculate(2,3));
	}
	public static void main (String args[]) {
		LambdaTest l=new LambdaTest();
		l.methodCalculator();
	}

}
