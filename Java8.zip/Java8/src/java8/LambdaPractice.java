package java8;
import java.util.ArrayList;
//public class LambdaPractice {
//    public static void main(String[] args) {
//    	 boolean value1 = 10 + 5 >= 2 + 13;
//    	    int value2 = 0;
//    	 
//    	    if (value1 == true) {
//    	        value2 = 5 * 3 + 10 / 2;
//    	    } else {
//    	        value2 = 5 / 3 + 10 * 2;
//    	    }
//    	 
//    	    System.out.println(value2);
//    }
//}
@FunctionalInterface  //It is optional  
interface factorial{  
    public int fact(int n);  
} 
public class LambdaPractice {
	static void m (StringBuilder sb1) {
        sb1.append("er");
    }
 
    static public void main(String[] args) {
        StringBuilder sb2 = new StringBuilder("moth");
        m(sb2);
        System.out.println(sb2);
        String product = "Pen";
        product.toLowerCase();
        product.concat(" BOX".toLowerCase());
        System.out.println(product);
      //  System.out.println(product.substring(4,6));
//	static void ac() {
//		System.out.println(111);
//		
//	}
//	 static StringBuffer sb;
//	    StringBuffer sb2;
//	public static void main(String[] args) {
//		LambdaPractice l=new LambdaPractice();
//		System.out.println("Result: " + 3 + 5);
//		System.out.println("Result: " + (3 + 5));
//		ac();
//		int i1 = 1, i2 = 2, i3 = 3;
//		int i4 = i1 + (i2 = i3);
//		System.out.println(i4);
//		sb.append(new LambdaPractice().go(new StringBuffer("hey")));
//        System.out.println(sb);
	factorial f=(int n)->{ 
		int s=1;
		while(n>0) {
		s=s*n;		
	    n--;
	}
		return s;
	
};
System.out.print(f.fact(5));
}
}

//System.out.println(s);
//if(n==1)
//	return 1;
//else
//    return n*fact(n--);
//
//String name = "Fred";
//System.out.println("Hello" + //Saying Hello
//        name);
//System.out.println("Good /* and " +
//        " greeting */ day!");
//System.out //A welcome messages
//        .println("Welcome " + name);
//System.out.println("Goodbye /* Farewell + name");
