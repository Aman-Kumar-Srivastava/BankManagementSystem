package java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.*;

public class JavaStream {
	public static void main(String args[]) {
		List<Integer> number = Arrays.asList(2, 3, 4, 5);
		List<Integer> square = number.stream().map(x -> x *x).collect(Collectors.toList());
		System.out.println(square);

		List<String> names = Arrays.asList("Reflection", "Collection", "Stream","Random");
		List<String> result = names.stream().filter(s->s.startsWith("R")).collect(Collectors.toList());
	    System.out.println(result);
	    List<String> result1 = names.stream().sorted().collect(Collectors.toList());
	    System.out.println(result1);
	    
	    
	    List<Integer> al=new ArrayList();
	    List<Integer> bl=new ArrayList();
	    List<Integer> cl=new ArrayList();
	    List<Integer> dl=new ArrayList();
	    al.add(1);
	    al.add(2);
	    al.add(4);
	    al.add(-1);
	    al.add(3);
	    System.out.println(al);
	    bl=al.stream().map(x->x*x).collect(Collectors.toList());
	    cl=al.stream().filter(x->x%2==0).collect(Collectors.toList());
	    dl=al.stream().sorted().collect(Collectors.toList());
	    System.out.println(bl);
	    System.out.println(cl);
	    System.out.println(dl);
	    
	    
	    Set<Integer> s=new HashSet();
	    s=al.stream().map(x->(x+10)).collect(Collectors.toSet());
	    System.out.println(s);
	    al.stream().map(x->(x+10)).forEach(y->System.out.print(y+"--"));
	    System.out.println();
	    //1 2 4 -1 3
	    int even = al.stream().filter(x->x%2==0).reduce(1,(ans,i)-> ans+i+2);
	    System.out.println("even-- "+even);
	    
	    Map<Character,Integer> map=new HashMap();
	    String s1="abhishekkumar";
	    char c1[]=s1.toCharArray();
	    for(char c: c1) {
	    	if(map.containsKey(c)) {
	    		map.put(c,map.get(c)+1);
	    	}
	    		else{
	    			map.put(c,1);
	    		}
	    }
	    System.out.println(map);
	    for(Map.Entry<Character, Integer> e: map.entrySet()){
	    	System.out.println(e.getKey()+"--"+e.getValue());
	    }
	    System.out.println();
	    map.entrySet().stream().forEach(System.out::print);
	    Set<Integer> has=new HashSet();
	    has.add(1);
	    has.add(2);
	    has.add(3);
	    Iterator itr=has.iterator();	
	    while(itr.hasNext()) {
	    	System.out.println(itr.next());
	    }
	    List<String> arr1
        = new ArrayList<String>();
    arr1.add("Geeks");
    arr1.add("For");
    arr1.add("Geeks");
    arr1.parallelStream().forEach(w -> {System.out.print(w);});
	}
}
