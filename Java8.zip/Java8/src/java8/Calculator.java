package java8;


@FunctionalInterface
 public interface Calculator {
	double calculate(int a, int b);
}
